<?php

declare(strict_types=1);

namespace App\Support\Operations;

use App\Models\Operation;
use App\Support\Backups\BackupLifecycle;
use App\Support\Backups\RestoreLifecycle;
use App\Support\Databases\DbLifecycle;
use App\Support\Databases\DumpLifecycle;
use App\Support\Databases\PgLifecycle;
use App\Support\Subscriptions\Lifecycle;
use App\Support\Tls\CertificateLifecycle;
use App\Support\Web\WebLifecycle;

/**
 * Wer nach einem Vorgang den Bestand nachzieht — die vollständige Liste.
 *
 * **Warum es diese Liste gibt.** Bis P2 kannte der Arbeiter genau einen
 * Lebenslauf und rief ihn direkt auf. Mit P3 kommt der zweite dazu, und damit
 * die Frage, die dieses Projekt schon mehrfach teuer beantwortet hat: Was
 * passiert, wenn jemand einen dritten schreibt und den Arbeiter nicht anfasst?
 * Antwort ohne diese Liste: Der Vorgang läuft durch, der Agent tut seine
 * Arbeit, und im Panel ändert sich nichts — ohne Fehler, ohne Meldung.
 *
 * `LifecycleReachTest` hält deshalb beide Richtungen zusammen: Jede Umsetzung
 * von {@see AfterOperation} steht hier, und jeder Eintrag hier ist eine.
 */
final class Lifecycles
{
    /**
     * **Die Reihenfolge ist keine Aufzählung, sondern eine Zusage.**
     * {@see Lifecycle} steht zuerst, weil er den Zustand des Abonnements setzt;
     * alle danach lesen ihn frisch aus der Datenbank. Liefe es umgekehrt, trüge
     * jeder Server-Block und jede Datenbanksperre noch den Zustand von vorher —
     * die Sperre stünde im Panel und die Webseite antwortete weiter.
     *
     * @var list<class-string<AfterOperation>>
     */
    public const HANDLERS = [
        Lifecycle::class,
        WebLifecycle::class,
        CertificateLifecycle::class,
        DbLifecycle::class,

        // P5b. Neben und nicht in DbLifecycle: Die Antworten der beiden
        // Rückbauoperationen haben nicht dieselbe Form (docs/38 §8).
        PgLifecycle::class,

        /*
         * **Eine Klasse je Gegenstand, nicht je System** (`docs/38 §21`,
         * Entscheidung 10). Was mit einer Sicherung geschieht, hängt an keinem
         * Datenbanksystem — nur die Namen der vier Aufgaben tun das, und die
         * stehen in `DumpLifecycle::tasks()`.
         */
        DumpLifecycle::class,

        /*
         * **P8: die Sicherung eines ganzen Abonnements.** Sie steht neben und
         * nicht in `DumpLifecycle` — dieselbe Begründung wie bei `PgLifecycle`:
         * Der Gegenstand ist ein anderer. Ein Dump ist eine Datenbank, eine
         * Sicherung ist ein Abonnement samt seinen Dumps, und die Antworten der
         * beiden Operationen haben nicht dieselbe Form.
         */
        BackupLifecycle::class,
        RestoreLifecycle::class,
    ];

    /**
     * Alle Aufgaben, die irgendein Lebenslauf beantwortet.
     *
     * @return list<string>
     */
    public static function handled(): array
    {
        $tasks = [];

        foreach (self::HANDLERS as $handler) {
            foreach ($handler::handles() as $task) {
                $tasks[$task] = true;
            }
        }

        return array_keys($tasks);
    }

    /**
     * Die Lebensläufe, die für diese Aufgabe zuständig sind.
     *
     * ## Der Befund, für den es diese Methode gibt
     *
     * Gemessen am 18. September 2026 auf `cloudsrv24`, im Nachlauf zu P8:
     * Nach einer **Sicherung** stand der Cronjob des Kunden zweimal in
     * `/etc/cron.d/`, beide Zeilen aktiv — sein Job lief doppelt. Und im
     * Ergebnis des `backup.create`-Vorgangs stand ein `restored`-Block mit
     * sechs Fehlschlägen, obwohl niemand etwas zurückgespielt hatte.
     *
     * Hier stand eine Schleife über **alle** Lebensläufe, ohne zu fragen,
     * welcher zuständig ist. Sieben von acht prüften `$operation->task` selbst
     * und taten deshalb nichts; {@see RestoreLifecycle}
     * prüfte nur, ob es ein Abonnement und eine Sicherung gibt — und bei einem
     * `backup.create` gibt es beides, denn der Gegenstand **ist** die
     * Sicherung. Es lief also eine vollständige Wiederherstellung gegen das
     * lebende Abonnement: Datenbanken neu anlegen, Zugänge neu anlegen,
     * Cronjobs neu anlegen.
     *
     * > **Ein Verteiler, der jeden Empfänger für jede Nachricht ruft,
     * > verlagert die Zuständigkeitsfrage in die Empfänger — und der erste,
     * > der sie nicht stellt, tut etwas, das niemand bestellt hat.**
     *
     * **Und `handles()` gab es die ganze Zeit.** Jeder Lebenslauf deklariert
     * es, der Name sagt genau das, und gelesen wurde es allein von
     * {@see self::handled()} für einen Wächter.
     *
     * > **Ein Feld, das geschrieben und nie gelesen wird, ist von aussen nicht
     * > von einem zu unterscheiden, das es nicht gibt** — und eines, das
     * > *fast* gelesen wird, ist schlimmer: Es sieht aus, als trüge es die
     * > Regel.
     *
     * ## Warum hier und nicht im Empfänger
     *
     * Ein zweiter Wächter in `RestoreLifecycle` hätte diesen einen Fall
     * geschlossen und die Frage beim nächsten Lebenslauf wieder gestellt. Die
     * sieben anderen verzweigen ohnehin auf `task` — sie tun für fremde
     * Aufgaben nichts, und das Filtern hier ändert an ihnen nichts
     * (gemessen: jeder liest `task`, bevor er handelt).
     *
     * @return list<AfterOperation>
     */
    private function zustaendig(Operation $operation): array
    {
        $task = (string) ($operation->task ?? '');
        $zustaendig = [];

        foreach (self::HANDLERS as $handler) {
            if (! in_array($task, $handler::handles(), true)) {
                continue;
            }

            /** @var AfterOperation $lifecycle */
            $lifecycle = app($handler);

            $zustaendig[] = $lifecycle;
        }

        return $zustaendig;
    }

    public function afterSuccess(Operation $operation): void
    {
        foreach ($this->zustaendig($operation) as $lifecycle) {
            $lifecycle->afterSuccess($operation);
        }
    }

    /**
     * Und dasselbe, wenn der Vorgang gescheitert ist.
     *
     * **Die Reihenfolge ist hier nicht dieselbe Zusage wie oben.** Beim Erfolg
     * baut einer auf dem Zustand des vorigen auf; beim Fehlschlag räumt jeder
     * nur sein eigenes auf. Sie bleibt trotzdem gleich, weil zwei Reihenfolgen
     * für dieselbe Liste eine Einladung sind, die falsche zu lesen.
     */
    public function afterFailure(Operation $operation): void
    {
        foreach ($this->zustaendig($operation) as $lifecycle) {
            $lifecycle->afterFailure($operation);
        }
    }
}
