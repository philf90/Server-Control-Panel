<?php

declare(strict_types=1);

namespace App\Support\Notify;

use App\Enums\AccountStatus;
use App\Enums\FindingCheck;
use App\Mail\CustomerNotice;
use App\Mail\DiagnoseReport;
use App\Models\Account;
use App\Models\Finding;
use App\Models\Subscription;
use App\Support\Plans\Quota;
use App\Support\Settings\Settings;
use App\Support\Tenancy\Tenancy;
use App\Support\Time\Clock;
use Closure;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Support\Facades\Mail;
use Throwable;

/**
 * Der Weg über das Relay — an den Kunden **und** an den Betreiber.
 *
 * ## Wer gemeint ist, folgt aus der Prüfung
 *
 * **Drei Prüfungen gehören dem Kunden** ({@see self::CUSTOMER}):
 * `quota.exceeded` misst **sein** Abonnement, und der Hinweis dazu steht seit
 * P1 in {@see Quota::TrafficGb}; seit B9 (`docs/142`) dazu `tls.expiry`, die
 * Laufzeit des Zertifikats seiner Domain, und `backup.latest`, seine jüngste
 * Sicherung. Die übrigen messen den Server, und der gehört dem Betreiber.
 *
 * > **Ein Kanal, der alles an alle trägt, hat keinen Empfänger, sondern eine
 * > Verteilerliste.**
 *
 * **Und je Prüfung genau ein Empfänger**, entschieden vom Betreiber am
 * 7. Oktober 2026 (`docs/142 §6`, Frage 1): Die Mail über ein ablaufendes
 * Zertifikat bekommt seitdem der Kunde und nicht mehr der Betreiber; der
 * sieht den Befund auf „Diagnose" und über den Webhook. Zwei Empfänger für
 * eine Prüfung hiessen einen zweiten Kanal, denn gebucht wird je Befund und
 * Kanal. **Was am Server liegt, bleibt beim Betreiber:** ein fehlendes
 * Zertifikat, eines mit dem falschen Namen, eines, das der Server nicht
 * ausliefert — darum heisst die Laufzeit `tls.expiry` und steht nicht als
 * Grund unter `tls.file`.
 *
 * Bis zum 21. September 2026 trug dieser Kanal **nur** die
 * Kontingentbefunde — B5 hatte keinen zweiten Empfänger, und die übrigen
 * Prüfungen hatten keinen Weg nach draussen. Mit B1 haben sie zwei.
 *
 * ## Die Adresse des Betreibers wird nicht erfunden
 *
 * Sie ist die seines Kontos. Eine eigene Einstellung „Meldeadresse" wäre eine
 * zweite Wahrheit neben `accounts.email` — und die zweite ist die, die
 * veraltet, wenn jemand sein Konto umträgt.
 *
 * > **Eine Angabe, die es schon gibt, bekommt keine zweite Stelle, nur weil
 * > ein neues Merkmal sie braucht.**
 *
 * ## Gesperrte Konten bekommen nichts
 *
 * Ein Konto, das sich nicht anmelden darf, bekommt auch keine Auskunft über
 * den Server — und das gilt für beide Empfänger, nicht nur für den einen.
 * {@see self::addressesOf()} ist die eine Stelle, an der das steht.
 *
 * ## Über ein Abonnement erfährt, wer es sieht — und jeder für sich
 *
 * **Bis zum 5. Oktober 2026 ging die Kundenmail an jedes aktive Konto des
 * Kunden, alle in einer Zeile `To`** (`docs/141 §0`). Damit las ein
 * Zusatzbenutzer, dem das Abonnement gar nicht zugewiesen ist, von dessen
 * Kontingenten — eine Auskunft, die ihm das Panel auf jeder Seite verweigert
 * —, und jeder Empfänger las die Adressen der anderen. Entschieden hat der
 * Betreiber am selben Tag: **wer das Abonnement sieht, je eine Mail.** Gefragt
 * wird dafür {@see Account::mayAccessSubscription()}, dieselbe Frage, die jede
 * Seite des Abonnements stellt; eine zweite Fassung davon hier wäre die, die
 * beim nächsten Rechtemodell nicht mitgeht.
 *
 * > **Eine Mail, die einer Seite nachfolgt, fragt dieselbe Policy wie die
 * > Seite — sonst sagt sie, was die Seite verweigert.**
 */
final class MailChannel implements Channel
{
    /**
     * Der Schlüssel dieses Kanals — als Konstante und nicht nur als Rückgabe.
     *
     * Wer ihn braucht, hat nicht immer eine Instanz: Die Einstellungsseite des
     * Mailversands fragt „zuletzt erfolgreich zugestellt" für genau diesen
     * Kanal. Ein zweites Mal hingeschriebenes `'mail'` wäre der Verweis ohne
     * Prüfung, an dem dieses Projekt am häufigsten verloren hat.
     */
    public const CHANNEL = 'mail';

    /**
     * Der Bündelschlüssel für alles, was dem Betreiber gehört.
     *
     * **Ein Schlüssel und kein leerer Wert.** Ein `''` oder `null` an dieser
     * Stelle trüge zwei Bedeutungen — „gehört dem Betreiber" und „hat keinen
     * Gegenstand" —, und `docs/901` hat gemessen, was das kostet: Eine Null,
     * die schon eine Bedeutung trägt, kann keine zweite bekommen.
     */
    private const OPERATOR = 'operator';

    /** Und das Gegenstück, damit kein Abonnementname zufällig `operator` heisst. */
    private const SUBSCRIPTION = 'subscription:';

    /**
     * Die Prüfungen, deren Befund dem Kunden gehört — siehe Kopf der Klasse.
     *
     * **Eine Liste und kein Vergleich an zwei Stellen.** Bündeln und Zustellen
     * fragen beide danach; stünde die Antwort zweimal da, bündelte der Kanal
     * einen Befund für den Kunden und schickte ihn dem Betreiber.
     *
     * @var list<FindingCheck>
     */
    public const CUSTOMER = [FindingCheck::QuotaExceeded, FindingCheck::TlsExpiry, FindingCheck::BackupLatest];

    public function __construct(
        private readonly Tenancy $tenancy,
        private readonly Settings $settings,
        private readonly CustomerFacts $facts,
    ) {}

    public function key(): string
    {
        return self::CHANNEL;
    }

    /**
     * Ohne eingetragenes Relay wird nichts gemeldet und nichts vermerkt.
     *
     * Eine Buchung zu schreiben hiesse, eine Zustellung zu behaupten, die es
     * nie gab — und die Meldung wäre für immer fort, weil dieselbe Zeile über
     * diesen Kanal nie wieder fällig wird.
     */
    public function usable(): bool
    {
        return $this->settings->mail()->usable();
    }

    /** Das Relay steht in den Einstellungen — das Panel weiss es selbst. */
    public function knownUsable(): bool
    {
        return $this->usable();
    }

    /**
     * Je Abonnement eine Mail an den Kunden, und alles Übrige in eine an den
     * Betreiber.
     *
     * **Je Abonnement und nicht je Art** (`docs/142 §4`): Ein Kunde, dessen
     * Platz knapp wird und dessen Sicherung scheitert, bekommt eine Mail mit
     * zwei Abschnitten. Ein Zertifikat nennt seine Domain und nicht sein
     * Abonnement — {@see CustomerFacts::subscriptionOf()} sucht es.
     */
    public function batchKey(FindingCheck $check, string $subject): string
    {
        if (! in_array($check, self::CUSTOMER, true)) {
            return self::OPERATOR;
        }

        return self::SUBSCRIPTION.($this->facts->subscriptionOf($check, $subject) ?? '');
    }

    /** @param  non-empty-list<Finding>  $findings */
    public function deliver(array $findings): Delivery
    {
        $erster = $findings[0];

        return in_array($erster->check, self::CUSTOMER, true)
            ? $this->toCustomer($this->facts->subscriptionOf($erster->check, $erster->subject) ?? '', $findings)
            : $this->toOperator($findings);
    }

    /**
     * An den Kunden: eine Nachricht je Abonnement und Empfänger — mit einem
     * Abschnitt je Art von Befund ({@see CustomerFacts::sections()}).
     *
     * **Je Empfänger eine eigene Nachricht und eine eigene Instanz.** Eine
     * Mailable sammelt Empfänger: `Mail::to()` hängt sie über `setAddress()`
     * an, statt sie zu ersetzen — dieselbe Instanz zweimal verschickt ginge
     * beim zweiten Mal an beide.
     *
     * **Angekommen ist sie, wenn sie bei einem angekommen ist.** Eine Adresse,
     * die das Relay dauerhaft abweist, liesse den Befund sonst fällig, und
     * jeder andere Empfänger bekäme dieselbe Mail jede Nacht wieder. Fällig
     * bleibt sie, wenn **keiner** sie bekommen hat — dann trägt der Weg nicht,
     * und der nächste Lauf versucht es für alle.
     *
     * @param  non-empty-list<Finding>  $findings
     */
    private function toCustomer(string $subscription, array $findings): Delivery
    {
        $empfaenger = $this->customerAddresses($subscription);

        if ($empfaenger === []) {
            return Delivery::WithoutRecipient;
        }

        $abschnitte = $this->facts->sections($subscription, $findings);
        $angekommen = 0;

        foreach ($empfaenger as $adresse) {
            if ($this->send(new CustomerNotice($subscription, $abschnitte), [$adresse]) === Delivery::Sent) {
                $angekommen++;
            }
        }

        return $angekommen > 0 ? Delivery::Sent : Delivery::Failed;
    }

    /**
     * An den Betreiber: **eine** Nachricht über alles, was fällig ist — aus
     * der Nacht oder aus der Messung der Dateisysteme alle fünf Minuten.
     *
     * @param  non-empty-list<Finding>  $findings
     */
    private function toOperator(array $findings): Delivery
    {
        $empfaenger = $this->operatorAddresses();

        if ($empfaenger === []) {
            /*
             * **Kein Fehlschlag.** Ein Server, dessen Betreiberkonto keine
             * Adresse trägt, ist nicht kaputt — und die Befunde bleiben
             * fällig, bis eine da ist. Ein `failed` färbte die Unit jede Nacht
             * rot für etwas, das auf der Kontenseite behoben wird.
             */
            return Delivery::WithoutRecipient;
        }

        return $this->send(new DiagnoseReport(self::lines($findings)), $empfaenger);
    }

    /** @param  list<string>  $empfaenger */
    private function send(CustomerNotice|DiagnoseReport $nachricht, array $empfaenger): Delivery
    {
        try {
            Mail::to($empfaenger)->send($nachricht);
        } catch (Throwable) {
            // Keine Buchung: Was nicht ankam, bleibt fällig. Der nächste Lauf
            // versucht es wieder, und bis dahin steht „zuletzt erfolgreich
            // zugestellt" unverändert da.
            return Delivery::Failed;
        }

        return Delivery::Sent;
    }

    /**
     * Die Zeilen der Betreibernachricht.
     *
     * **Sie trägt den Gegenstand mit**, weil sie im Gegensatz zur Kundenmail
     * über mehrere Prüfungen und mehrere Orte zugleich spricht: „Dienst" ohne
     * den Namen der Unit ist kein Befund, sondern eine Stimmung.
     *
     * > **Ein Protokoll, das die Art der Handlung nennt und nicht ihren
     * > Gegenstand, beantwortet die Frage, die niemand stellt.**
     *
     * **Und `seit` statt einer Dauer.** Ein Zeitpunkt bleibt wahr, wenn die
     * Mail einen Tag später gelesen wird; „seit 14 Stunden" ist ab dem
     * nächsten Augenblick falsch.
     *
     * @param  non-empty-list<Finding>  $findings
     * @return non-empty-list<array{label: string, subject: string, detail: string, since: string}>
     */
    private static function lines(array $findings): array
    {
        return array_map(static fn (Finding $f): array => [
            'label' => $f->check->label().': '.$f->check->sentence($f->reason),
            'subject' => $f->check->subjectLabel().' '.$f->subject,
            'detail' => (string) ($f->detail ?? '—'),
            'since' => (string) Clock::display($f->first_seen_at),
        ], $findings);
    }

    /**
     * An wen die Kundennachricht geht.
     *
     * **An die Konten des Kunden und nicht an eine Adresse am Abonnement** —
     * eine solche gibt es nicht, und sie zu erfinden hiesse, eine zweite
     * Wahrheit neben `accounts.email` zu pflegen. **Und von denen an die, die
     * das Abonnement sehen** (Kopf der Klasse): die Kundenkonten und die
     * Zusatzbenutzer, denen es zugewiesen ist.
     *
     * @return list<string>
     */
    private function customerAddresses(string $subscription): array
    {
        return $this->withoutClamp(static function () use ($subscription): array {
            $abo = Subscription::query()->where('name', $subscription)->first();

            if ($abo === null) {
                return [];
            }

            return self::addressesOf(
                $abo->customer?->accounts(),
                static fn (Account $konto): bool => $konto->mayAccessSubscription($abo),
            );
        });
    }

    /**
     * An wen die Betreibernachricht geht.
     *
     * **An die Betreiber und nicht an jeden Administrator.** Der Unterschied
     * ist seit A9 gebaut: Ein Administrator sieht den Server über
     * `inspect-server`, gedreht wird über `operate-server`. Eine Meldung über
     * einen toten Dienst ist eine Aufforderung zu handeln, und handeln darf
     * hier der Betreiber.
     *
     * @return list<string>
     */
    private function operatorAddresses(): array
    {
        return $this->withoutClamp(static fn (): array => self::addressesOf(Account::operators()));
    }

    /**
     * Die brauchbaren Adressen einer Kontenabfrage.
     *
     * **Eine Stelle für beide Empfänger.** Die Bedingung ist dieselbe — ein
     * Konto, das sich nicht anmelden darf, bekommt auch keine Auskunft über
     * den Server —, und sie zweimal hinzuschreiben hiesse, sie beim nächsten
     * Mal an einer der beiden Stellen zu vergessen.
     *
     * @param  Builder<Account>|Relation<Account, *, *>|null  $konten
     * @param  (Closure(Account): bool)|null  $darf  ob ein Konto diese Auskunft bekommen darf
     * @return list<string>
     */
    private static function addressesOf(mixed $konten, ?Closure $darf = null): array
    {
        if ($konten === null) {
            return [];
        }

        /** @var Collection<int, Account> $gefunden */
        $gefunden = $konten
            ->where('status', AccountStatus::Active->value)
            ->whereNotNull('email')
            ->orderBy('id')
            ->get();

        $adressen = [];

        foreach ($gefunden as $konto) {
            $mail = (string) $konto->email;

            if ($mail !== '' && ($darf === null || $darf($konto))) {
                $adressen[] = $mail;
            }
        }

        return $adressen;
    }

    /**
     * Die Mandantenklammer für diese eine Frage lösen.
     *
     * Dieser Lauf hat kein angemeldetes Konto; im Grundzustand käme eine leere
     * Liste zurück, und das sähe aus wie „dieser Kunde hat kein Konto".
     *
     * > **Eine Frage, die im Grundzustand alles verweigert, antwortet mit
     * > einer leeren Liste und nicht mit einem Fehler.**
     *
     * @param  callable(): list<string>  $frage
     * @return list<string>
     */
    private function withoutClamp(callable $frage): array
    {
        /** @var list<string> $adressen */
        $adressen = [];

        $this->tenancy->withoutRestriction(static function () use ($frage, &$adressen): void {
            $adressen = $frage();
        });

        return $adressen;
    }
}
