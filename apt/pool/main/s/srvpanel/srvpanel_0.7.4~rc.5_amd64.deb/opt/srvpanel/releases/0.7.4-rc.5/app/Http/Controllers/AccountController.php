<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\AccountStatus;
use App\Enums\AccountType;
use App\Enums\AdminRole;
use App\Models\Account;
use App\Support\Audit\Audit;
use App\Support\Authorization\LastOperator;
use App\Support\Authorization\Sessions;
use App\Support\Passwords\Policy;
use App\Support\Time\Clock;
use App\Support\Web\Page;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Die Adminkonten — anlegen, ändern, sperren.
 *
 * ## Wofür es diese Seite gibt
 *
 * Bis zum 24. August 2026 entstand ein Adminkonto **ausschliesslich** über
 * `srvpanel:admin` auf der Kommandozeile. Wer einen zweiten Menschen an das
 * Panel lassen wollte, brauchte dafür SSH und root — also genau die Rechte, die
 * das Panel dem Administrator gerade nicht geben will (`docs/20 §6.1`).
 *
 * > **Ein Rechtemodell, dessen zweite Rolle sich nur mit den Rechten der ersten
 * > anlegen lässt, hat keine zweite Rolle.**
 *
 * ## Nur Adminkonten, und das ist keine Filterfrage
 *
 * Kundenkonten stehen am Kunden. Zwei Listen derselben Zeilen wären zwei Wege
 * zum selben Ort, und der zweite veraltet.
 *
 * **Durchgesetzt wird das an der Routenbindung** und nicht hier: `{admin}` löst
 * über `SrvPanelServiceProvider` nur Adminkonten auf. Eine
 * Prüfung in jeder Methode wäre dieselbe Regel an vier Stellen — und beim
 * fünften Weg zum Konto fehlte sie.
 *
 * ## Was diese Seite **nicht** kann
 *
 * **Die Anmeldeadresse ändern** (`docs/82 §2.4`). Sie ist die Anmeldung und
 * steht im Protokoll; ihr Wechsel ist ein eigener Vorgang mit Bestätigung und
 * gehört nicht in ein Formular, das auch den Namen ändert.
 *
 * ## Löschen gibt es seit dem 10. September 2026 — und warum es das vorher nicht gab
 *
 * `docs/82 §9` hat es offengelassen, solange das Protokoll seinen Handelnden
 * über `nullOnDelete()` verlor: Ein gelöschtes Adminkonto zog seine ganze
 * Geschichte auf `null`, und Sperren war die ehrlichere Antwort.
 *
 * Seit `docs/901` hält `RecordsTheActor` den Namen
 * auf der Protokollzeile selbst fest — abgeschrieben beim Anlegen der Zeile,
 * wie `subscription_name` seit `docs/35`. Damit trägt der Satz nicht mehr, und
 * {@see self::destroy()} ist der dritte Weg, den `LastOperator` seit A9
 * erwartet.
 *
 * > **Löschen und Vergessen sind zwei Dinge. Die Zeile darf verschwinden; was
 * > sie getan hat, darf es nicht.**
 */
final class AccountController extends Controller
{
    /**
     * Warum niemand sein eigenes Konto löscht.
     *
     * **Hier und nicht in {@see LastOperator}:** Der Aussperrschutz beantwortet
     * „bleibt ein aktiver Betreiber übrig", und das ist eine andere Frage.
     * Der Satz sagt, **warum** abgelehnt wurde und **was** hilft — eine
     * Ablehnung ohne Ausweg ist eine Sackgasse mit Begründung.
     */
    private const SELF_REFUSAL = 'Das eigene Konto lässt sich nicht löschen. '
        .'Ein zweiter Betreiber kann es tun.';

    public function index(Request $request): Response
    {
        $accounts = Account::query()
            ->where('type', AccountType::Admin)
            ->orderBy('name')
            ->paginate(Page::SIZE)
            ->withQueryString();

        /*
         * **Die Zahl der aktiven Betreiber geht mit auf die Seite**, damit die
         * Liste den Grund zeigen kann, aus dem ein Konto keine Knöpfe hat.
         *
         * Gefragt wird dieselbe Stelle, die es später abweist. Eine zweite
         * Bedingung in der Vue-Datei — „wenn nur eine Zeile Betreiber ist" —
         * wäre eine zweite Fassung von {@see LastOperator}, und die zweite ist
         * die, die veraltet.
         */
        $operators = LastOperator::active();

        $self = (int) ($request->user()?->getAuthIdentifier() ?? 0);

        return Inertia::render('Accounts/Index', [
            'accounts' => Page::from($accounts, static fn (Account $account): array => [
                'id' => (int) $account->id,
                'name' => $account->name,
                'email' => $account->email,
                'role' => $account->role?->value,
                'role_label' => $account->role?->label(),
                'status' => $account->status->value,
                'status_label' => $account->status->label(),
                'two_factor' => $account->hasTwoFactor(),
                'last_login_at' => Clock::display($account->last_login_at),
                'is_last_operator' => LastOperator::isLast($account),

                /*
                 * **Ob das die eigene Zeile ist** (`docs/901 §3.5`). Die Seite
                 * zeigt dort keinen Löschknopf, und die Frage kommt aus
                 * derselben Quelle, die {@see self::destroy()} später stellt.
                 *
                 * Eine zweite Bedingung in der Vue-Datei — „vergleiche mit dem
                 * angemeldeten Konto aus der geteilten Ablage" — wäre eine
                 * zweite Fassung derselben Regel, und die zweite veraltet.
                 */
                'is_self' => (int) $account->id === $self,
            ]),
            'operators' => $operators,
        ]);
    }

    public function create(): Response
    {
        return Inertia::render('Accounts/Form', [
            /*
             * **`admin` und nicht `account`** — der Name des geteilten
             * Schlüssels ist vergeben (siehe {@see \Tests\Feature\SharedPropTest}).
             *
             * Hier stand `account`, und damit überschrieb diese Seite das
             * angemeldete Konto in der geteilten Nutzlast. Sichtbar wurde es in
             * der Fusszeile der Seitenleiste: beim Anlegen verschwand der Name,
             * beim Ändern stand dort der Name des **bearbeiteten** Kontos.
             *
             * Gefährlicher als das Sichtbare ist das Danebenliegende:
             * `PanelLayout` schaltet über `account.is_admin` die ganze
             * Navigation um. Dass sie nicht umsprang, lag allein daran, dass
             * das Feld hier fehlt und `undefined === false` falsch ergibt.
             *
             * > **Ein Feld, dessen Fehlen den Schaden verhindert, ist keine
             * > Absicherung — es ist ein Zufall mit Ablaufdatum.**
             */
            'admin' => null,
            'values' => [
                'name' => '',
                'email' => '',

                /*
                 * **Administrator als Vorgabe, und das ist die Entscheidung
                 * dieser Seite.** Der Betreiber gibt es schon — wer hier ein
                 * Konto anlegt, will in aller Regel jemanden, der Kunden
                 * verwaltet, und nicht einen zweiten Menschen mit root.
                 *
                 * Die sichere Richtung ist zugleich die häufige. Wäre der
                 * Betreiber vorgewählt, entstünde die weitere Vollmacht durch
                 * ein Feld, das niemand angesehen hat.
                 */
                'role' => AdminRole::Administrator->value,
            ],
            'roles' => self::roles(),
            'isLastOperator' => false,
        ]);
    }

    public function store(Request $request, Audit $audit): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('accounts', 'email')],
            'role' => ['required', Rule::enum(AdminRole::class)],

            /*
             * **Das Passwort kommt aus dem Browser**, erzeugt von
             * `PasswordFields` — derselben Komponente wie beim Anlegen eines
             * Kunden und beim eigenen Passwortwechsel.
             *
             * Der erste Wurf von `docs/82 §2.4` plante das Gegenteil: Der
             * Server erzeugt es und zeigt es einmalig an. Das wäre eine zweite
             * Bauart für etwas gewesen, das dieses Panel seit P1 auf eine Art
             * macht — und die Begründung dagegen steht im Kopf von
             * {@see Policy::generate()}: Ein Passwort, das der Server ausliefert,
             * steht in jedem Puffer auf dem Weg.
             *
             * Geprüft wird es trotzdem gegen dieselbe Richtlinie. Die
             * Kommandozeile war einmal der Weg, an ihr vorbei ein schwaches
             * Passwort für ein Adminkonto zu setzen; ein zweiter soll hier
             * nicht entstehen.
             */
            'password' => ['required', 'confirmed', ...Policy::rules()],

            /*
             * **Am Feld heisst es „Anmeldeadresse", und die Meldung sagt
             * dasselbe.** Ohne den dritten Wert läse der Betreiber „Das Feld
             * E-Mail-Adresse ist erforderlich" und suchte ein Feld, das auf
             * dieser Seite nicht steht.
             *
             * Der Name gehört an den Aufruf und nicht in die Sprachdatei: Dort
             * bedeutet `email` an fünfzehn anderen Stellen die E-Mail-Adresse
             * eines Kunden, und die heisst dort auch so.
             *
             * > **Ein Wächter über die Vollständigkeit sagt nichts über die
             * > Richtigkeit** (`docs/66`, Befund 15).
             */
        ], [], ['email' => 'Anmeldeadresse']);

        $account = Account::query()->create([
            'type' => AccountType::Admin,
            'role' => AdminRole::from($data['role']),
            'customer_id' => null,
            'name' => $data['name'],
            'email' => Str::lower(trim($data['email'])),
            'password' => $data['password'],
            'status' => AccountStatus::Active,
        ]);

        /*
         * **Mit `context` und nicht nur mit `target`** (`docs/66`, Befund 7).
         * Ein Eintrag `account.created` ohne die Rolle beantwortet die Frage,
         * die niemand stellt — bei einem Adminkonto ist „welche Rolle" die
         * einzige, für die man das Protokoll aufschlägt.
         */
        $audit->success('account.created', $account, [
            'name' => $account->name,
            'email' => $account->email,
            'role' => $account->role?->value,
        ]);

        return redirect()->route('accounts.index')
            ->with('success', "Konto {$account->name} angelegt.");
    }

    public function edit(Request $request, Account $admin): Response
    {
        return Inertia::render('Accounts/Form', [
            // `admin` und nicht `account`: siehe create() darüber.
            'admin' => [
                'id' => (int) $admin->id,
                'name' => $admin->name,
                'email' => $admin->email,
                'two_factor' => $admin->hasTwoFactor(),
                'last_login_at' => Clock::display($admin->last_login_at),
            ],
            'values' => [
                'name' => $admin->name,
                'email' => $admin->email,
                'role' => $admin->role?->value,
                'status' => $admin->status->value,
            ],
            'roles' => self::roles(),

            /*
             * **Die offenen Sitzungen dieses Kontos** (`docs/82 §2.5`).
             *
             * Sie stehen an der Kontenseite und nicht an einer eigenen: Wer
             * fragt „wer ist gerade angemeldet", fragt es über ein Konto — und
             * eine zweite Liste derselben Zeilen wäre ein zweiter Weg zum
             * selben Ort.
             */
            'sessions' => Sessions::of($admin, $request->session()->getId()),

            /*
             * **Ob die Liste überhaupt beantwortbar ist** (Befund 15 aus
             * `docs/84`). Ohne diese Angabe wäre „keine offenen Sitzungen"
             * nicht von „nicht nachgesehen" zu unterscheiden — und die
             * beruhigende Lesart gewänne.
             */
            'sessionsReadable' => Sessions::readable(),

            /*
             * **Mit denselben Augen wie {@see self::update()}.** Zeigte das
             * Formular seine Auswahl an einer anderen Frage als die Prüfung
             * dahinter, stünde dort ein Knopf, den der Aufruf danach abweist —
             * ein Fehler, der in diesem Projekt schon mehrfach teuer war.
             */
            'isLastOperator' => LastOperator::isLast($admin),
        ]);
    }

    public function update(Request $request, Account $admin, Audit $audit): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'role' => ['required', Rule::enum(AdminRole::class)],
            'status' => ['required', Rule::enum(AccountStatus::class)],
        ]);

        $role = AdminRole::from($data['role']);
        $status = AccountStatus::from($data['status']);

        /*
         * **Eine Frage nach dem Zielzustand und nicht nach der Handlung.**
         * Herabstufen und Sperren sehen im Formular verschieden aus und sind
         * dieselbe Aussperrung; {@see LastOperator::permits()} bekommt deshalb,
         * was nachher gelten soll, und entscheidet daraus.
         */
        if (! LastOperator::permits($admin, $role, $status)) {
            throw ValidationException::withMessages(['role' => LastOperator::refusal()]);
        }

        $before = ['role' => $admin->role?->value, 'status' => $admin->status->value];

        $admin->forceFill([
            'name' => $data['name'],
            'role' => $role,
            'status' => $status,
        ])->save();

        $audit->success('account.updated', $admin, [
            'name' => $admin->name,
            'email' => $admin->email,
            'role' => $before['role'] === $role->value
                ? $role->value
                : $before['role'].' → '.$role->value,
            'status' => $before['status'] === $status->value
                ? $status->value
                : $before['status'].' → '.$status->value,
        ]);

        return redirect()->route('accounts.index')
            ->with('success', "Konto {$admin->name} geändert.");
    }

    /**
     * Ein neues Passwort für ein fremdes Konto.
     *
     * **Ohne das alte**, im Unterschied zum eigenen Passwortwechsel: Der
     * Betreiber kennt es nicht, und das ist der Fall, für den es diesen Weg
     * gibt. Was ihn trägt, ist die Fähigkeit an der Route — wer sie hat, hat
     * den Server ohnehin.
     *
     * **Kein zweiter Faktor wird dabei zurückgesetzt.** Wer sich mit seinem
     * zweiten Faktor ausgesperrt hat, kommt auch mit einem neuen Passwort nicht
     * herein; dafür bleibt `srvpanel:admin` der Rückweg (`docs/82 §3`,
     * Falle 3). Ein Knopf, der beides zugleich abräumt, machte aus dem
     * Passwortwechsel eine Übernahme des Kontos.
     */
    public function password(Request $request, Account $admin, Audit $audit): RedirectResponse
    {
        $request->validate([
            'password' => ['required', 'confirmed', ...Policy::rules()],
        ]);

        $admin->forceFill([
            'password' => Hash::make((string) $request->input('password')),
        ])->save();

        $audit->success('account.password.reset', $admin, [
            'name' => $admin->name,
            'email' => $admin->email,
        ]);

        return redirect()->route('accounts.index')
            ->with('success', "Passwort von {$admin->name} gesetzt.");
    }

    /**
     * Eine Sitzung dieses Kontos beenden.
     *
     * **Auch die eigene**, und das ist Absicht: „Ich sitze an einem fremden
     * Rechner" ist der häufigste Anlass, diese Liste überhaupt aufzuschlagen.
     * Die Seite schreibt dran, welche Zeile die laufende ist — ein Knopf, der
     * das verschwiege, wäre die Falle.
     */
    public function endSession(Request $request, Account $admin, Audit $audit): RedirectResponse
    {
        $data = $request->validate(['session' => ['required', 'string', 'max:255']]);

        $gone = Sessions::forget($admin, (string) $data['session']);

        if (! $gone) {
            /*
             * **Kein Fehler, sondern die Auskunft.** Eine Sitzung, die es nicht
             * mehr gibt, ist genau der Zustand, den der Betreiber herstellen
             * wollte — sie kann zwischen Anzeige und Klick abgelaufen sein.
             */
            return redirect()->route('accounts.edit', $admin)
                ->with('notice', 'Diese Sitzung gibt es nicht mehr.');
        }

        $audit->success('account.session.ended', $admin, [
            'name' => $admin->name,
            'email' => $admin->email,
        ]);

        return redirect()->route('accounts.edit', $admin)
            ->with('success', 'Die Sitzung wurde beendet.');
    }

    /**
     * Ein Adminkonto löschen — hart, mit Abschrift im Protokoll.
     *
     * **Bis zum 10. September 2026 gab es diesen Weg nicht** (`docs/82 §9`):
     * Solange das Protokoll seinen Handelnden über `nullOnDelete()` verlor, war
     * Sperren die ehrlichere Antwort. Seit `docs/901` hält
     * `RecordsTheActor` den Namen auf der
     * Protokollzeile fest, und damit trägt der Satz nicht mehr.
     *
     * > **Löschen und Vergessen sind zwei Dinge. Die Zeile darf verschwinden;
     * > was sie getan hat, darf es nicht.**
     *
     * ## Zwei Prüfungen, und sie beantworten verschiedene Fragen
     *
     * **Das eigene Konto nicht** — und diese Prüfung gehört ausdrücklich
     * **nicht** in {@see LastOperator}. Die Klasse beantwortet „bleibt ein
     * aktiver Betreiber übrig"; wer sich als Betreiber Nr. 2 von 2 löscht,
     * sperrt niemanden aus und schiesst sich trotzdem ins Knie. Zwei Fragen,
     * zwei Stellen.
     *
     * **Und der Aussperrschutz** mit dem Zielzustand eines gelöschten Kontos:
     * keine Rolle, nicht aktiv. Kein neuer Mechanismus, ein Aufruf.
     *
     * ## Die Reihenfolge im Rumpf ist tragend
     *
     * Der Protokolleintrag steht **vor** dem Löschen, und sein `context` trägt
     * Name, Anmeldeadresse und Rolle: `audit_events` benutzt `nullableMorphs`,
     * `target_id` zeigt danach auf eine Zeile, die es nicht mehr gibt. Dieser
     * eine Eintrag ist die Stelle, an der die Bindung „dieser Name gehörte zu
     * dieser Adresse und dieser Kennung" festgehalten wird — die Abschrift auf
     * den übrigen Zeilen trägt nur den Namen.
     *
     * Und die Sitzungen gehen davor, weil `sessions.user_id` als einziger
     * Verweis auf ein Konto **keinen** Fremdschlüssel trägt: Dort räumt sonst
     * niemand auf (`docs/901 §1.1`).
     */
    public function destroy(Request $request, Account $admin, Audit $audit): RedirectResponse
    {
        if ((int) $request->user()?->getAuthIdentifier() === (int) $admin->id) {
            throw ValidationException::withMessages(['account' => self::SELF_REFUSAL]);
        }

        if (! LastOperator::permits($admin, null, AccountStatus::Disabled)) {
            throw ValidationException::withMessages(['account' => LastOperator::refusal()]);
        }

        $name = $admin->name;

        Sessions::forgetAll($admin);

        $audit->success('account.deleted', $admin, [
            'name' => $admin->name,
            'email' => $admin->email,
            'role' => $admin->role?->value,
        ]);

        $admin->delete();

        return redirect()->route('accounts.index')
            ->with('success', "Konto {$name} gelöscht.");
    }

    /**
     * Die Rollen für das Auswahlfeld.
     *
     * Aus dem Enum und nicht als Liste im Formular: Eine dritte Rolle
     * (`docs/82 §4`) stünde sonst an zwei Stellen, und die zweite ist die, die
     * veraltet.
     *
     * @return list<array{value: string, label: string}>
     */
    private static function roles(): array
    {
        return array_map(
            static fn (AdminRole $role): array => ['value' => $role->value, 'label' => $role->label()],
            AdminRole::cases(),
        );
    }
}
