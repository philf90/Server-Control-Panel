<?php

declare(strict_types=1);

namespace SrvPanel\Agent;

use RuntimeException;

/**
 * Fehler, die als Ergebnis über das Protokoll zurückgehen.
 *
 * Der Code ist maschinenlesbar und Teil der Schnittstelle; die Meldung ist für
 * Menschen und darf die tatsächliche Ausgabe des Systems enthalten. Was nicht
 * hineingehört: interne Pfade des Agenten, Stacktraces, Speicheradressen.
 */
final class AgentException extends RuntimeException
{
    public const BAD_REQUEST = 'bad_request';

    public const UNKNOWN_OP = 'unknown_op';

    public const DENIED = 'denied';

    public const TIMEOUT = 'timeout';

    public const EXEC_FAILED = 'exec_failed';

    public const NOT_FOUND = 'not_found';

    public const INTERNAL = 'internal';

    /**
     * Der Aufrufer ist weggegangen, das Programm wurde abgebrochen.
     *
     * Kein Fehler im eigentlichen Sinn, aber ein anderes Ergebnis als Erfolg —
     * und die Anwendung muss die beiden unterscheiden können, um einen
     * abgebrochenen Vorgang nicht als fehlgeschlagen auszuweisen.
     */
    public const CANCELLED = 'cancelled';

    /** @param array<string,mixed> $details */
    public function __construct(
        public readonly string $errorCode,
        string $message,
        public readonly array $details = [],
    ) {
        parent::__construct($message);
    }

    /** @param array<string,mixed> $details */
    public static function badRequest(string $message, array $details = []): self
    {
        return new self(self::BAD_REQUEST, $message, $details);
    }

    public static function denied(string $message): self
    {
        return new self(self::DENIED, $message);
    }

    /** @param array<string,mixed> $details */
    public static function execFailed(string $message, array $details = []): self
    {
        return new self(self::EXEC_FAILED, $message, $details);
    }

    /** @return array{code:string,message:string,details:array<string,mixed>} */
    public function toArray(): array
    {
        return [
            'code' => $this->errorCode,
            'message' => $this->getMessage(),
            'details' => $this->details,
        ];
    }
}
