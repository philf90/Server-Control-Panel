<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Support\Cron\ServerZone;
use App\Support\Databases\Usage as DatabaseUsage;
use App\Support\Metrics\Daily;
use App\Support\Settings\Settings;
use App\Support\Subscriptions\Usage;
use Illuminate\Console\Command;
use SrvPanel\Agent\AgentException;

/**
 * Der belegte Speicher aller Abonnements — eine Messung, dann Schluss.
 *
 * **Ein Timer und kein Dauerlauf.** Der Kennzahlensammler läuft als Prozess,
 * weil er im Zehnsekundentakt messen muss und der Zeitplan von Laravel nur
 * Minutenauflösung hat. Hier ist es umgekehrt: Der belegte Speicher ändert
 * sich langsam, eine Viertelstunde ist reichlich genau, und ein Prozess, der
 * 899 von 900 Sekunden schläft, ist ein Prozess, den jemand überwachen muss.
 *
 * **Auch kein Eintrag im Laravel-Zeitplan.** Der bräuchte `schedule:run` jede
 * Minute — also einen Cron-Eintrag oder einen weiteren Dauerlauf, den es auf
 * diesem Server nicht gibt. Der Timer ruft dieses Kommando direkt auf; was
 * ihn startet, steht in `packaging/systemd/srvpanel-usage.timer` und ist von
 * aussen sichtbar.
 *
 * **Seit P5 misst es zweierlei, und trotzdem gibt es einen Timer.** Der belegte
 * Platz der Datenbanken kommt aus `information_schema` und nicht aus der
 * Quota-Datei; das sind zwei Quellen, aber derselbe Anlass. Zwei Zeitgeber im
 * Viertelstundentakt wären zwei Dinge, die jemand überwachen muss, für eine
 * Messung, die dieselbe Frage beantwortet (`docs/36 §9`).
 *
 * **Und seit dem 28. September 2026 schreibt es auch den Verlauf.** Zwei der
 * fünf Kacheln auf der Abonnementseite — Speicherplatz und Datenbanken — lasen
 * Kennzahlen aus der verdichteten Tabelle, die kein Lauf ablegte: Gemessen
 * wurde hier, gespeichert nur der gegenwärtige Wert (`docs/138 §0` Punkt 1).
 * Entschieden hat der Betreiber, dass dieser Lauf sie schreibt und kein neuer
 * — gemessen wird ohnehin hier, und ein zweiter Zeitgeber wäre ein drittes Ding
 * zum Überwachen für dieselbe Messung.
 */
final class MeasureUsage extends Command
{
    protected $signature = 'srvpanel:usage';

    protected $description = 'Misst den belegten Speicher aller Abonnements und den Platz ihrer Datenbanken';

    /**
     * **Als Feld und nicht als Parameter durchgereicht.** {@see self::measureDisk()}
     * ist privat und wird von genau einer Stelle gerufen; ein zweiter Parameter
     * dort hiesse, ihn durch eine Kette zu tragen, die nichts damit zu tun hat.
     */
    private Settings $settings;

    public function handle(Usage $usage, DatabaseUsage $databases, Settings $settings, Daily $daily): int
    {
        $this->settings = $settings;

        /*
         * **Die zweite Messung läuft auch dann, wenn die erste nichts liefert.**
         * Sie hängen an verschiedenen Voraussetzungen — `usrquota` am Mount
         * hier, ein laufender MariaDB dort. Ein Server ohne Quota hätte sonst
         * auch keine Datenbankgrössen, und der Grund dafür stünde nirgends.
         */
        $quota = $this->measureDisk($usage);
        $schemas = $this->measureDatabases($databases);

        /*
         * **Der Verlauf kommt nach beiden Messungen, und auch dann, wenn eine
         * ausfiel.** {@see Daily::levels()} legt nur ab, was an diesem Tag
         * gemessen wurde; eine ausgefallene Messung hinterlässt dort die
         * letzte gelungene des Tages oder gar nichts, aber nie die von
         * gestern. Davor gerufen, schriebe er die Werte der vorigen
         * Viertelstunde.
         */
        $this->recordLevels($daily);

        return $quota && $schemas ? self::SUCCESS : self::FAILURE;
    }

    /**
     * Platz und Datenbanken des laufenden Tages in die verdichtete Tabelle.
     *
     * **Welcher Tag läuft, fragt {@see ServerZone} und nicht dieses Panel** —
     * derselbe Griff wie im Nachtlauf, aus demselben Grund: `config/app.php`
     * steht auf UTC, und die Tage der Tabelle sind Kalendertage des Servers.
     * Eine Messung um 01:30 Ortszeit auf einem Server in `+0200` gehörte nach
     * `now()` noch zum Vortag und überschriebe dessen letzte Messung.
     *
     * **Ohne lesbare Zone wird nichts abgelegt, und das ist kein
     * Fehlschlag.** Ein Rückfall auf UTC wäre genau der Notnagel, gegen den
     * {@see ServerZone::current()} ein `null` zurückgibt. Rot wird der Lauf
     * trotzdem nicht: Die Messung selbst ist gelungen, und der Nachtlauf, der
     * aus demselben Grund nichts ablegen kann, scheitert daran laut — zwei rote
     * Units für eine Ursache wären eine zu viel.
     */
    private function recordLevels(Daily $daily): void
    {
        $zone = ServerZone::current();

        if ($zone === null) {
            $this->warn('Die Zeitzone des Servers ist nicht lesbar — Platz und Datenbanken bekommen heute keine Zeile im Verlauf.');

            return;
        }

        $heute = now()->setTimezone($zone)->toDateString();
        $geschrieben = $daily->levels($heute, $zone);

        $this->line(sprintf(
            'Verlauf für %s (%s): %d Abonnement(s) mit Platz, %d mit Datenbanken.',
            $heute,
            $zone->getName(),
            $geschrieben['disk'],
            $geschrieben['databases'],
        ));
    }

    /** Der belegte Speicher über die Dateisystem-Quota. */
    private function measureDisk(Usage $usage): bool
    {
        try {
            $result = $usage->measure();
        } catch (AgentException $error) {
            $this->error('Messung scheiterte: '.$error->getMessage());

            return false;
        }

        /*
         * **Was der Lauf gesehen hat, bleibt stehen.** Bis zum 10. August 2026
         * stand diese Antwort nur im Journal des Timers — die Übersicht wusste
         * nichts vom fehlenden Quota-System, und der Betreiber erfuhr davon
         * erst, wenn er ein Abonnement anlegte und in dessen Vorgangsausgabe
         * `setquota: Cannot find mountpoint for device` las. Neben „fertig".
         */
        $this->settings->saveDiskQuota(
            $result['available'],
            $result['available'] ? null : (string) ($result['reason'] ?? ''),
        );

        if ($result['available'] === false) {
            /*
             * **Kein Fehlschlag.** Eine Installation ohne `usrquota` auf dem
             * Mount ist eingerichtet, wie sie eingerichtet ist — der Timer
             * würde sonst alle fünfzehn Minuten rot und stünde damit dauerhaft
             * neben allem, was tatsächlich kaputt ist. Der Grund steht im
             * Journal, und die Oberfläche zeigt „nicht gemessen".
             */
            $this->warn('Keine Dateisystem-Quota: '.($result['reason'] ?? ''));

            return true;
        }

        /*
         * **Dieselben drei Zahlen wie unten, und aus demselben Anlass.** Der
         * Befund kam bei den Datenbanken (siehe {@see measureDatabases()}), die
         * Lücke stand aber in beiden Messungen: `measured` sind die
         * geschriebenen Zeilen, und ein Abonnement ohne Eintrag in der
         * Quota-Datei bekommt eine gemessene Null. „N Abonnement(s) gemessen"
         * hätte also auch eine Quota-Datei bestätigt, aus der nichts zu lesen
         * war.
         */
        $this->info(sprintf(
            '%d Abonnement(s) geschrieben; die Quota-Datei nannte %d Systembenutzer, %d davon zugeordnet.',
            $result['measured'],
            $result['reported'],
            $result['matched'],
        ));

        /*
         * **Ohne Verweis auf ein Werkzeug, weil es keines gibt.** Für ein
         * Schema ohne Zeile ist `srvpanel db --prune` der Weg; für einen
         * Systembenutzer, den kein Abonnement kennt, gibt es kein Gegenstück —
         * sein Heimatverzeichnis liegt dann noch da. Der Verweis auf ein
         * Kommando, das nicht hilft, wäre schlimmer als keiner.
         */
        if ($result['reported'] !== $result['matched']) {
            $this->warn(sprintf(
                '%d Systembenutzer der Quota-Datei waren keinem Abonnement zuzuordnen.',
                $result['reported'] - $result['matched'],
            ));
        }

        return true;
    }

    /** Der belegte Platz der Datenbanken — dieselbe Nachsicht, anderer Grund. */
    private function measureDatabases(DatabaseUsage $databases): bool
    {
        try {
            $result = $databases->measure();
        } catch (AgentException $error) {
            $this->error('Messung der Datenbanken scheiterte: '.$error->getMessage());

            return false;
        }

        if ($result['available'] === false) {
            $this->warn('Kein Datenbankserver: '.($result['reason'] ?? ''));

            return true;
        }

        /*
         * **Drei Zahlen, und die erste allein war kein Beleg.** Der Abnahmelauf
         * vom 8. August 2026 meldete „2 Datenbank(en) gemessen" — und genau das
         * hätte auch dagestanden, wenn die Abfrage gar nichts geliefert hätte:
         * Eine Datenbank ohne Treffer bekommt `size_bytes = 0` als gemessene Null.
         * Nach zwei Läufen war damit unbelegt, ob `db.usage` überhaupt etwas
         * liest.
         *
         * `gemeldet` ist, was der Server genannt hat, `zugeordnet`, wie viel
         * davon zu einer Zeile des Panels passte. Eine Null bei `gemeldet` neben
         * einer Zwei bei `geschrieben` fällt jetzt auf.
         */
        $this->info(sprintf(
            '%d Datenbank(en) geschrieben; der Server meldete %d Schema(ta), %d davon zugeordnet.',
            $result['measured'],
            $result['reported'],
            $result['matched'],
        ));

        /*
         * **Ein Missverhältnis ist eine Warnung und kein Fehlschlag.** Ein
         * Schema, das der Server nennt und das Panel nicht kennt, ist ein
         * Befund für `srvpanel db` — kein Grund, den Zeitgeber rot zu machen.
         * Umgekehrt ist eine Zeile ohne Treffer der Normalfall bei einer
         * frischen, leeren Datenbank.
         */
        if ($result['reported'] !== $result['matched']) {
            $this->warn(sprintf(
                '%d Schema(ta) des Panels waren keiner Zeile zuzuordnen — mit `srvpanel db` nachsehen.',
                $result['reported'] - $result['matched'],
            ));
        }

        return true;
    }
}
