<?php

declare(strict_types=1);

namespace App\Policies;

use App\Enums\Permission;
use App\Models\Account;
use App\Models\Domain;
use App\Models\Subscription;
use App\Support\Plans\Feature;
use App\Support\Tls\WildcardOrder;

/**
 * Wer was mit einer Domain darf.
 *
 * **Die Frage steht am Abonnement, nicht an der Domain.** Wer ein Abonnement
 * benutzen darf, darf seine Domains anlegen und ändern; die Domain selbst
 * trägt kein eigenes Rechtemodell. Das ist die Zusage aus §6.1 — „Kunde: alles
 * innerhalb seiner Abonnements, im Rahmen von Plan und Kontingent" — und sie
 * bleibt genau dann wahr, wenn hier nichts danebensteht.
 *
 * **Kein `Gate::before` für Admins**, aus demselben Grund wie in
 * {@see SubscriptionPolicy}: Eine einzige Zeile „Admin darf alles" beantwortet
 * auch Fragen, die es nicht gibt, und ein vertippter Fähigkeitsname fiele
 * ausschliesslich bei Kunden auf.
 *
 * **Die Mandantenklammer hat vorher schon entschieden.** Eine fremde Domain
 * ist bei der Modellbindung „nicht gefunden" und erreicht diese Policy gar
 * nicht. Sie prüft trotzdem — zwei Schichten, und wenn eine ausfällt, hält die
 * andere (§6.2).
 */
final class DomainPolicy
{
    public function viewAny(Account $account): bool
    {
        return $account->isAdmin() || $account->accessibleSubscriptionIds() !== [];
    }

    public function view(Account $account, Domain $domain): bool
    {
        if ($account->isAdmin()) {
            return true;
        }

        return $account->mayAccessSubscription((int) $domain->subscription_id);
    }

    /**
     * Anlegen — geprüft am Abonnement, in dem sie entstehen soll.
     *
     * Laravel reicht die weiteren Routenparameter an die Policy durch; die
     * Route trägt deshalb `can:create,App\Models\Domain,subscription`. Ohne
     * das Abonnement liesse sich nur fragen, ob dieses Konto *irgendwo*
     * Domains anlegen darf — und ein Kunde mit zwei Abonnements dürfte dann in
     * beiden, sobald er in einem darf.
     */
    public function create(Account $account, Subscription $subscription): bool
    {
        if ($account->isAdmin()) {
            return true;
        }

        // Zusatzbenutzer brauchen dasselbe Recht wie zum Ändern: Wer eine
        // Domain anlegen darf, bestimmt, was ausgeliefert wird.
        return $account->mayAccessSubscription($subscription)
            && $subscription->usable()
            && $account->hasPermission($subscription, Permission::FilesWrite);
    }

    public function update(Account $account, Domain $domain): bool
    {
        return $this->mayChange($account, $domain);
    }

    public function delete(Account $account, Domain $domain): bool
    {
        return $this->mayChange($account, $domain);
    }

    /**
     * Die PHP-Einstellungen einer Domain ändern.
     *
     * **Eigene Fähigkeit, weil sie an einer Planfreigabe hängt.** `update`
     * fragt, ob jemand die Domain anfassen darf; das hier fragt zusätzlich, ob
     * der Plan diese Funktion überhaupt hergibt. Beides in eine Methode zu
     * legen hiesse, dass ein Kunde ohne die Freigabe auch das DocumentRoot
     * nicht mehr ändern könnte — und der Plan sagt darüber nichts.
     */
    public function updatePhp(Account $account, Domain $domain): bool
    {
        if (! $this->mayChange($account, $domain)) {
            return false;
        }

        if ($account->isAdmin()) {
            return true;
        }

        $subscription = $domain->subscription;

        return $subscription !== null
            && $subscription->feature(Feature::PhpSettings->value)
            && $account->hasPermission($subscription, Permission::PhpSettings);
    }

    /**
     * Ein eigenes Zertifikat für diese Domain hinterlegen.
     *
     * **Dieselbe Bauart wie {@see self::updatePhp()}, und aus demselben
     * Grund:** `update` fragt, ob jemand die Domain anfassen darf; das hier
     * fragt zusätzlich, ob der Plan diese Funktion hergibt. Die Freigabe steht
     * seit den Plänen als `Feature::CertificateUpload` da — mit Beschriftung,
     * Hinweis und Recht. Gebaut werden musste die Funktion dahinter, nicht das
     * Rechtemodell.
     *
     * **Warum das nicht an `update` hängt.** Wer hier hochlädt, legt einen
     * privaten Schlüssel auf den Server, und was danach ausgeliefert wird,
     * sieht jeder Besucher. Das ist eine andere Grössenordnung als ein
     * DocumentRoot zu ändern — und der Betreiber entscheidet über den Plan,
     * ob ein Kunde sie bekommt.
     */
    public function uploadCertificate(Account $account, Domain $domain): bool
    {
        if (! $this->mayChange($account, $domain)) {
            return false;
        }

        if ($account->isAdmin()) {
            return true;
        }

        $subscription = $domain->subscription;

        return $subscription !== null
            && $subscription->feature(Feature::CertificateUpload->value)
            && $account->hasPermission($subscription, Permission::Certificates);
    }

    /**
     * Einen Platzhalter zu dieser Domain bestellen.
     *
     * **Dieselbe Grössenordnung wie das Hochladen, aus dem umgekehrten Grund.**
     * Ein Platzhalter deckt jede Unterdomain der Zone — auch eine, die einem
     * *anderen* Abonnement gehört (`docs/34 §3`). Wer ihn bestellt, ändert
     * damit, was der Server über fremde Namen aussagt, und das hängt nicht am
     * Recht, ein DocumentRoot zu ändern.
     *
     * **`DnsEdit` und nicht `Certificates`.** Ein Platzhalter geht nur über
     * DNS-01, und DNS-01 heisst: In der Zone wird ein Eintrag angelegt. Wer die
     * Zone nicht verwalten darf, lässt sie auch nicht über diesen Umweg ändern
     * — der Betreiber behält sie dann bei sich und bestellt selbst.
     *
     * **Ob es gerade geht, steht nicht hier.** Fehlende Zugangsdaten sind keine
     * Frage der Berechtigung, sondern eine Auskunft; sie steht in
     * {@see WildcardOrder::obstacle()}. Eine Policy, die
     * „darf" und „geht gerade" vermischt, sagt dem Betreiber „keine
     * Berechtigung", wo „kein Token hinterlegt" gemeint ist.
     */
    public function orderWildcard(Account $account, Domain $domain): bool
    {
        if (! $this->mayChange($account, $domain)) {
            return false;
        }

        if ($account->isAdmin()) {
            return true;
        }

        $subscription = $domain->subscription;

        return $subscription !== null
            && $subscription->feature(Feature::DnsEdit->value)
            && $account->hasPermission($subscription, Permission::Certificates);
    }

    /**
     * Die Protokolle einer Domain lesen.
     *
     * `FilesRead` und nicht `Statistics`: Ein Fehlerprotokoll enthält Pfade,
     * Dateinamen und im Zweifel Bruchstücke aus dem Quelltext der Anwendung.
     * Wer Dateien nicht lesen darf, soll sie auch nicht über den Umweg des
     * Protokolls sehen.
     */
    public function viewLogs(Account $account, Domain $domain): bool
    {
        if ($account->isAdmin()) {
            return true;
        }

        $subscription = $domain->subscription;

        return $subscription !== null
            && $account->mayAccessSubscription($subscription)
            && $account->hasPermission($subscription, Permission::FilesRead);
    }

    /**
     * Ändern und Entfernen haben dieselben Bedingungen.
     *
     * Ein gesperrtes Abonnement bleibt sichtbar und unbenutzbar — sonst wäre
     * „gesperrt" nur ein Etikett in der Oberfläche.
     */
    private function mayChange(Account $account, Domain $domain): bool
    {
        $subscription = $domain->subscription;

        if ($subscription === null) {
            return false;
        }

        if ($account->isAdmin()) {
            return true;
        }

        return $account->mayAccessSubscription($subscription)
            && $subscription->usable()
            && $account->hasPermission($subscription, Permission::FilesWrite);
    }
}
