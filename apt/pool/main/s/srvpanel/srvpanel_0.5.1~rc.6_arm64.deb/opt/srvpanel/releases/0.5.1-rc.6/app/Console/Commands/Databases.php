<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Enums\DatabaseEngine;
use App\Models\Database;
use App\Models\DatabaseDump;
use App\Models\DbUser;
use App\Support\Databases\DatabasePrune;
use App\Support\Databases\DumpIntegrity;
use App\Support\Settings\Settings;
use App\Support\Tenancy\Tenancy;
use Illuminate\Console\Command;
use SrvPanel\Agent\AgentException;
use SrvPanel\Agent\Client;
use SrvPanel\Agent\Pg\Server;

/**
 * Der Datenbankserver von der Kommandozeile — nachsehen und aufräumen.
 *
 * **Zwei Dinge, und beide gehören auf dieselbe Seite**, weil beide dieselbe
 * Frage beantworten: Was liegt auf diesem Server, das das Panel angeht?
 *
 * `srvpanel db` liest — Version, Geschmacksrichtung, Horchadresse, der Bestand
 * des Panels, und was ein misslungener Rückbau liegengelassen hat.
 * `srvpanel db --prune` räumt es weg, nach Rückfrage und in der Reihenfolge, in
 * der es sicher ist.
 *
 * **Warum es das überhaupt gibt.** `docs/35` hat freigelegt, dass sich in
 * diesem System ein Zertifikat nie löschen liess — ein Jahr lang, weil `create`
 * zuerst gebaut wurde und danach funktionierte. P5 legt drei weitere Dinge auf
 * dem System ab: Schemata, Datenbankbenutzer und Sicherungsdateien. Der Weg
 * zurück ist deshalb Teil desselben Beitrags und nicht die Nacharbeit, an die
 * ein Jahr später niemand denkt.
 *
 * **`--remote=on|off` ist der Schalter aus `docs/36 §12`**, und er steht hier
 * und nicht im Panel: Er lässt einen Dienst auf einer erreichbaren Adresse
 * horchen, und das ist eine serverweite Änderung. Leitbild 1 — „der Bestand ist
 * Gesetz" — verbietet, sie nebenbei zu tun, weil ein Kunde ein Häkchen gesetzt
 * hat. Erst wenn der Server tatsächlich horcht, bietet das Panel einem Kunden
 * überhaupt an, einen Zugang für eine fremde Adresse anzulegen.
 *
 * **Und der Neustart wird angesagt, bevor er passiert.** Der Datenbankserver
 * trägt auch das Panel; ein `--remote` ohne Rückfrage wäre eine Unterbrechung,
 * die niemand erwartet hat.
 */
final class Databases extends Command
{
    protected $signature = 'srvpanel:db
        {--prune : Reste eines misslungenen Rückbaus entfernen — Schemata, Zugänge und Sicherungen}
        {--dry-run : Mit --prune: nur zeigen, was entfernt würde}
        {--remote= : on oder off — ob der Datenbankserver auf einer erreichbaren Adresse horcht}
        {--bind=0.0.0.0 : Mit --remote=on: 0.0.0.0 für IPv4 oder :: für beide Stapel}
        {--postgresql= : on oder off — ob das Panel PostgreSQL-Datenbanken anbietet}';

    protected $description = 'Zeigt den Datenbankserver und räumt auf, was ein Rückbau liegenliess';

    public function handle(Client $agent, DatabasePrune $prune, Tenancy $tenancy, Settings $settings): int
    {
        if ($this->option('prune') === true) {
            return $this->prune($agent, $prune);
        }

        if ($this->option('remote') !== null) {
            return $this->remote($agent, $tenancy);
        }

        if ($this->option('postgresql') !== null) {
            return $this->postgres($agent, $settings, $tenancy);
        }

        return $this->showServer($agent, $prune, $tenancy);
    }

    /**
     * Nachsehen — der Server und der Bestand.
     *
     * **Der Server wird gefragt und nicht das Panel.** Was hier interessiert,
     * ist der Unterschied zwischen beiden: Ein Schema, das im Panel steht und
     * auf dem Server fehlt, ist eine andere Lage als eines, das der Server hat
     * und das Panel nicht. Die erste Frage beantwortet `db.server.info`, die
     * zweite `srvpanel db --prune`.
     */
    private function showServer(Client $agent, DatabasePrune $prune, Tenancy $tenancy): int
    {
        /*
         * **Ein toter Agent beendet dieses Kommando nicht mehr.** Hier stand
         * ein `return self::FAILURE`, und damit war alles Weitere unerreichbar
         * — auch das, was das Panel ganz allein beantworten kann: sein eigener
         * Bestand und die Frage, ob die Sicherungen noch zu ihren Dateien
         * passen. Wer nachsieht, weil etwas kaputt ist, bekommt jetzt beides
         * statt einer Zeile. Der Rückgabewert bleibt trotzdem 1.
         */
        $info = [];
        $agentFehlt = false;

        try {
            $info = $agent->call('db.server.info', [], $this->actor());
        } catch (AgentException $error) {
            $this->error('Der Agent hat abgewiesen: '.$error->getMessage());
            $agentFehlt = true;
        }

        if (($info['available'] ?? false) !== true) {
            $this->warn('Kein Datenbankserver erreichbar: '.($info['reason'] ?? 'kein Grund genannt'));
        } else {
            $this->line(sprintf(
                '%s %s — %s',
                $info['flavour'] ?? 'unbekannt',
                $info['version'] ?? '?',
                ($info['usable'] ?? false) === true
                    ? 'nutzbar'
                    : 'nicht nutzbar: '.($info['reason'] ?? 'kein Grund genannt'),
            ));

            $this->line(sprintf(
                'Horcht auf %s — Fernzugriff %s.',
                $info['bind_address'] ?? 'unbekannt',
                ($info['remote'] ?? false) === true ? 'möglich' : 'aus',
            ));
        }

        /*
         * **Ohne Mandantenklammer, und ausdrücklich.** Auf der Kommandozeile
         * ist niemand angemeldet; der Grundzustand der Klammer ist „nichts",
         * und damit zählte dieses Kommando null Datenbanken auf einem Server
         * voller Datenbanken. Dieselbe Stelle, derselbe Name wie in
         * `Lifecycle::afterSuccess()` und `Usage::apply()`.
         */
        $bestand = $tenancy->withoutRestriction(static fn (): array => [
            'databases' => Database::query()->count(),
            'users' => DbUser::query()->count(),
            'dumps' => DatabaseDump::query()->count(),
        ]);

        $this->line(sprintf(
            '%d Datenbank(en), %d Zugang/Zugänge, %d Sicherung(en) im Bestand.',
            $bestand['databases'],
            $bestand['users'],
            $bestand['dumps'],
        ));

        /*
         * **Befristete Zugänge, die stehengeblieben sind.** Das Zurückspielen
         * legt einen an und entfernt ihn im `finally`; ein abgebrochener Lauf —
         * Stromausfall, SIGKILL — kann trotzdem einen zurücklassen, und das
         * wäre ein Zugang ohne Besitzer. Der Agent meldet nur solche, die älter
         * als eine Stunde sind (`DbServerInfo::GRACE_SECONDS`) — einer von vor
         * fünf Minuten gehört sehr wahrscheinlich zu einem Lauf, der gerade
         * arbeitet.
         */
        $stale = is_array($info['stale_users'] ?? null) ? $info['stale_users'] : [];

        if ($stale !== []) {
            $this->warn(sprintf('%d befristete(r) Zugang/Zugänge blieben stehen:', count($stale)));

            foreach ($stale as $user) {
                $this->line('  '.$user);
            }

            $this->line('Sie gehen mit `srvpanel db --prune`.');
        }

        $this->reportDumpSizes($tenancy);

        $plan = $prune->plan();

        if ($plan['total'] === 0) {
            $this->info('Nichts liegengeblieben.');
        }

        if ($plan['total'] > 0) {
            $this->warn(sprintf('%d Zeile(n) ohne Abonnement — siehe `srvpanel db --prune`.', $plan['total']));
            $this->printPlan($plan);
        }

        return $agentFehlt ? self::FAILURE : self::SUCCESS;
    }

    /**
     * Was der Bestand über eine Sicherung sagt, gegen die Datei gehalten.
     *
     * **Der Anlass ist eine Zahl, die niemand je geprüft hätte.** Am 9. August
     * 2026 stand auf `cloudsrv24` in `database_dumps.bytes` für eine Sicherung
     * 69255, auf der Platte lagen 69362 — und `bytes` ist genau die Zahl, die
     * dem Kunden als „Grösse" angezeigt wird. Woher die Abweichung dieser einen
     * Zeile kam, war nicht mehr zu klären; **der Fund ist, dass es keine Rolle
     * spielte, weil nichts die beiden je gegeneinander hielt**
     * (`docs/36 §22.3w`).
     *
     * Dieselbe Familie wie das `GRANT`, das sein Schema überlebte, und die
     * Zeile, die ihre Datei überlebte: eine Angabe im Bestand, die auf etwas
     * ausserhalb zeigt, ohne dass jemand nachsieht. Keinen der drei hat ein
     * Test gefunden, sondern ein Abnahmelauf.
     *
     * **Gemeldet und nicht repariert.** Was hier auffällt, ist entweder eine
     * falsche Zahl oder eine fehlende Datei — das eine ein Schönheitsfehler,
     * das andere ein Datenverlust. Wer löscht, weiss, was er löscht; dieselbe
     * Entscheidung wie bei den befristeten Zugängen oben.
     */
    private function reportDumpSizes(Tenancy $tenancy): void
    {
        /** @var list<array{name: string, grund: string}> $befunde */
        $befunde = [];
        $geprueft = 0;

        /** @var list<DatabaseDump> $dumps */
        $dumps = $tenancy->withoutRestriction(
            static fn (): array => DatabaseDump::query()->with('subscription')->get()->all()
        );

        foreach ($dumps as $dump) {
            // Nur fertige: Eine Sicherung, die noch läuft oder gescheitert ist,
            // hat noch keine Datei. Sie hier zu melden wäre eine Warnung für den
            // Regelfall, und die liest nach zwei Tagen niemand mehr.
            if (! $dump->status->usable()) {
                continue;
            }

            $path = $dump->path();

            if ($path === null) {
                continue;
            }

            $geprueft++;

            $grund = DumpIntegrity::reason($dump->bytes === null ? null : (int) $dump->bytes, $path);

            if ($grund !== null) {
                $befunde[] = ['name' => $dump->storage_name, 'grund' => $grund];
            }
        }

        if ($befunde === []) {
            if ($geprueft > 0) {
                $this->line(sprintf('%d Sicherung(en) geprüft: Grösse und Datei stimmen überein.', $geprueft));
            }

            return;
        }

        $this->warn(sprintf('%d von %d Sicherung(en) weichen von ihrer Datei ab:', count($befunde), $geprueft));

        foreach ($befunde as $befund) {
            $this->line(sprintf('  %s — %s', $befund['name'], $befund['grund']));
        }
    }

    /**
     * Aufräumen — erst auf dem System, dann im Bestand.
     *
     * **Die Reihenfolge ist dieselbe wie bei `srvpanel tls --prune`, und aus
     * demselben Grund:** Bricht der Agent ab, bleibt die Zeile stehen und zeigt
     * weiter auf das, was sie meint — ein zweiter Lauf holt es nach.
     * Andersherum wäre das Schema danach unauffindbar, und es läge mit den
     * Daten eines Kunden in `/var/lib/mysql`, ohne dass noch irgendetwas darauf
     * zeigt.
     *
     * **Zugänge vor Schemata.** Ein Zugang, dessen Schema schon weg ist, ist
     * ein Zugang auf nichts; ein Schema, dessen Zugang noch da ist, ist ein
     * offener Weg zu Daten. Von den beiden Zwischenzuständen ist der erste der
     * harmlosere.
     */
    private function prune(Client $agent, DatabasePrune $prune): int
    {
        $plan = $prune->plan();

        if ($plan['total'] === 0) {
            $this->info('Nichts liegengeblieben.');

            return self::SUCCESS;
        }

        $this->line(sprintf('%d Zeile(n) ohne Abonnement:', $plan['total']));
        $this->printPlan($plan);

        if ($this->option('dry-run') === true) {
            $this->info('--dry-run: es wurde nichts angefasst.');

            return self::SUCCESS;
        }

        /*
         * Vorgabe `false`: Ohne Rückfrage — etwa unter `--no-interaction` —
         * wird nichts gelöscht. Bei einem Kommando, das die Daten eines Kunden
         * von der Platte nimmt, ist das die richtige Richtung. Wortgleich zu
         * `srvpanel tls --prune`.
         */
        if (! $this->confirm('Diese Reste entfernen? Der Vorgang ist nicht rückgängig zu machen.', false)) {
            $this->line('Abgebrochen.');

            return self::SUCCESS;
        }

        $failed = 0;

        foreach ($plan['users'] as $user) {
            $failed += $this->removeOne(
                $agent,
                'db.user.remove',
                ['name' => $user['name'], 'host' => $user['host'], 'user' => $this->prefixOf($user['name'])],
                $user['name'].'@'.$user['host'],
                fn (): int => $prune->forgetUser($user['id']),
            );
        }

        foreach ($plan['databases'] as $database) {
            $failed += $this->removeOne(
                $agent,
                'db.database.remove',
                ['name' => $database['name'], 'user' => $this->prefixOf($database['name'])],
                $database['name'],
                fn (): int => $prune->forgetDatabase($database['id']),
            );
        }

        foreach ($plan['dumps'] as $dump) {
            $failed += $this->removeOne(
                $agent,
                'db.dump.remove',
                ['subscription' => $dump['subscription'], 'storage' => $dump['name']],
                $dump['name'],
                fn (): int => $prune->forgetDump($dump['id']),
            );
        }

        if ($failed > 0) {
            $this->error(sprintf('%d Rest(e) blieben liegen — ein zweiter Lauf holt sie nach.', $failed));

            return self::FAILURE;
        }

        $this->info('Aufgeräumt.');

        return self::SUCCESS;
    }

    /**
     * Einen Rest entfernen: erst der Agent, dann die Zeile.
     *
     * @param  array<string, mixed>  $arguments
     * @param  callable(): int  $forget
     * @return int 1, wenn er liegenblieb
     */
    private function removeOne(Client $agent, string $operation, array $arguments, string $label, callable $forget): int
    {
        try {
            $agent->call($operation, $arguments, $this->actor());
        } catch (AgentException $error) {
            $this->error("  {$label}: {$error->getMessage()}");

            return 1;
        }

        $forget();
        $this->line("  {$label}: entfernt");

        return 0;
    }

    /**
     * Der Systembenutzer aus einem Namen.
     *
     * **Er wird gebraucht, obwohl das Abonnement fort ist.** Der Agent prüft
     * jede Operation gegen das Präfix — `Names::belongsTo()` —, damit ein
     * `DROP DATABASE mysql` an dieser Zeile scheitert. Die Prüfung entfällt
     * nicht, nur weil hier niemand mehr zuständig ist; sie bekommt das Präfix
     * aus dem Namen selbst, und der stammt aus einer abgelegten Zeile, die der
     * Agent seinerzeit erzeugt hat.
     */
    private function prefixOf(string $name): string
    {
        return explode('_', $name, 2)[0];
    }

    /**
     * @param  array{
     *     databases: list<array{id: int, name: string, subscription: string, size_bytes: int|null}>,
     *     users: list<array{id: int, name: string, host: string, subscription: string}>,
     *     dumps: list<array{id: int, name: string, subscription: string, bytes: int|null}>,
     *     total: int,
     * }  $plan
     */
    private function printPlan(array $plan): void
    {
        foreach ($plan['databases'] as $database) {
            $this->line(sprintf(
                '  Datenbank %s (%s, %s)',
                $database['name'],
                $database['subscription'],
                $this->size($database['size_bytes'], 'nicht gemessen'),
            ));
        }

        foreach ($plan['users'] as $user) {
            $this->line(sprintf('  Zugang %s@%s (%s)', $user['name'], $user['host'], $user['subscription']));
        }

        foreach ($plan['dumps'] as $dump) {
            $this->line(sprintf(
                '  Sicherung %s (%s, %s)',
                $dump['name'],
                $dump['subscription'],
                $this->size($dump['bytes'], 'Grösse unbekannt'),
            ));
        }
    }

    /**
     * Eine Byte-Zahl in der Einheit, die sie noch unterscheidbar lässt.
     *
     * **Hier stand zweimal `intdiv($bytes, 1024 * 1024).' MB'`,** und das ist
     * genau die Rundung, die der dritte Abnahmelauf als Fehler gezeigt hat: Eine
     * Datenbank mit 300 KB und eine leere lesen sich beide als „0 MB". Wer diese
     * Liste ansieht, sucht meist nach etwas, das er vermisst — und dann ist der
     * Unterschied zwischen „leer" und „klein" die ganze Auskunft (docs/36
     * §22.3j).
     */
    private function size(?int $bytes, string $whenNull): string
    {
        if ($bytes === null) {
            return $whenNull;
        }

        if ($bytes < 1024) {
            return $bytes.' B';
        }

        if ($bytes < 1024 * 1024) {
            return intdiv($bytes, 1024).' KB';
        }

        if ($bytes < 1024 * 1024 * 1024) {
            return number_format($bytes / (1024 * 1024), 1, ',', '.').' MB';
        }

        return number_format($bytes / (1024 * 1024 * 1024), 1, ',', '.').' GB';
    }

    /** @return array<string, string> */
    /**
     * Den Fernzugriff ein- oder ausschalten (`docs/36 §12`).
     *
     * **Drei Dinge stehen vor dem Aufruf, und jedes hat einen Anlass.**
     *
     * 1. **Wer ausschaltet, erfährt vorher, wen er aussperrt.** Ein Zugang für
     *    eine fremde Adresse ist in MariaDB ein eigener Benutzer; nach
     *    `--remote=off` erreicht ihn niemand mehr, und die Anwendung dahinter
     *    steht. Die Zahl kommt aus dem Bestand des Panels — der Agent kennt sie
     *    nicht, und er soll sie auch nicht kennen.
     * 2. **Der Neustart wird angesagt.** Der Datenbankserver trägt auch das
     *    Panel. Eine Rückfrage vor einer Unterbrechung ist das Mindeste;
     *    Vorgabe `false`, wie bei `--prune`, damit `--no-interaction` nichts tut.
     * 3. **Gemeldet wird, worauf der Server danach horcht** — seine Antwort und
     *    nicht die Datei, die wir geschrieben haben. Genau hier fällt auf, wenn
     *    eine andere Include-Datei gewinnt.
     */
    private function remote(Client $agent, Tenancy $tenancy): int
    {
        $mode = strtolower(trim((string) $this->option('remote')));

        if (! in_array($mode, ['on', 'off'], true)) {
            $this->error('--remote erwartet on oder off.');

            return self::FAILURE;
        }

        $address = (string) $this->option('bind');

        if ($mode === 'on' && ! in_array($address, ['0.0.0.0', '::'], true)) {
            $this->error('--bind erwartet 0.0.0.0 (IPv4) oder :: (beide Stapel).');

            return self::FAILURE;
        }

        $fern = $tenancy->withoutRestriction(
            static fn (): int => DbUser::query()->where('host', '!=', 'localhost')->count(),
        );

        if ($mode === 'off' && $fern > 0) {
            $this->warn(sprintf(
                '%d Zugang/Zugänge sind für eine fremde Adresse angelegt. Nach dem Ausschalten '
                .'erreicht sie niemand mehr — die Zeilen bleiben, die Verbindung nicht.',
                $fern,
            ));
        }

        $this->line($mode === 'on'
            ? sprintf('Der Datenbankserver wird auf %s horchen. Die IP-Beschränkung gilt in MariaDB '
                .'und nicht im Paketfilter — die Firewall kommt mit P9.', $address)
            : 'Der Datenbankserver wird wieder nur lokal erreichbar sein.');

        if (! $this->confirm('Dafür wird der Datenbankserver neu gestartet. Das Panel ist dabei kurz ohne Datenbank. Weiter?', false)) {
            $this->line('Abgebrochen.');

            return self::SUCCESS;
        }

        try {
            $result = $agent->call('db.remote.access', ['mode' => $mode, 'address' => $address], $this->actor());
        } catch (AgentException $error) {
            $this->error('Der Agent hat abgewiesen: '.$error->getMessage());

            return self::FAILURE;
        }

        $this->line(sprintf('%s: %s', $result['path'] ?? '?', $mode === 'on' ? 'geschrieben' : 'entfernt'));

        $this->line(sprintf(
            'Horcht auf %s — Fernzugriff %s.',
            $result['bind_address'] ?? 'unbekannt',
            ($result['remote'] ?? false) === true ? 'möglich' : 'aus',
        ));

        /*
         * **Die Gegenprobe, und sie ist der Grund für die Zeile darüber.** Der
         * Agent meldet, was der Server nach dem Neustart sagt. Weicht das von
         * dem ab, was gewünscht war, ist der Lauf nicht erfolgreich, sondern
         * ein Befund — meistens eine andere Include-Datei, die später gelesen
         * wird als unsere.
         */
        if ((bool) ($result['remote'] ?? false) !== ($mode === 'on')) {
            $this->error(
                'Der Server horcht nicht so, wie es angefordert wurde. Vermutlich setzt eine andere '
                .'Include-Datei die Horchadresse später — sie werden lexikalisch gelesen.',
            );

            return self::FAILURE;
        }

        return self::SUCCESS;
    }

    /**
     * Die PostgreSQL-Fläche freischalten oder wieder schliessen (`docs/38 §7`).
     *
     * **Dieser Schalter installiert nichts.** Er sagt, ob das Panel
     * PostgreSQL-Datenbanken *anbietet* — installiert wird über den Knopf in
     * „Einstellungen → Datenbankserver" (`docs/38 §21`, Entscheidung 10). Die
     * beiden zu trennen ist der Punkt: Ein Server kann ein PostgreSQL tragen,
     * das dem Betreiber gehört, und eine Fläche, die von selbst aufgeht, sobald
     * `pg_lsclusters` etwas findet, schriebe Kundendatenbanken in einen
     * Cluster, den niemand dafür vorgesehen hat.
     *
     * **Deshalb ist auch kein Neustart im Spiel** — und deshalb steht die
     * Installation, anders als `--remote`, hinter einem Knopf: `apt-get install
     * postgresql` fasst MariaDB nicht an, und die Anfrage, die den Vorgang
     * anstösst, verliert ihre Verbindung nicht.
     *
     * **Was beim Abschalten passiert, steht vorher da.** Vorhandene
     * PostgreSQL-Datenbanken werden nicht angerührt; sie laufen weiter, und der
     * Kunde erreicht sie mit seinen Zugangsdaten. Was verschwindet, ist die
     * Fläche im Panel. Das ist ein Unterschied, den man gesagt bekommen muss,
     * bevor man ihn macht.
     */
    private function postgres(Client $agent, Settings $settings, Tenancy $tenancy): int
    {
        $mode = strtolower(trim((string) $this->option('postgresql')));

        if (! in_array($mode, ['on', 'off'], true)) {
            $this->error('--postgresql erwartet on oder off.');

            return self::FAILURE;
        }

        $an = $mode === 'on';

        if ($an) {
            /*
             * **Der Zustand des Servers wird gezeigt und nicht geprüft.** Der
             * Schalter ist eine Absicht, und eine Absicht darf einem Zustand
             * vorausgehen: Wer erst freischaltet und dann installiert, soll
             * dabei nicht in eine Fehlermeldung laufen. Gesagt wird es
             * trotzdem, sonst steht am Ende eine offene Fläche ohne Server
             * dahinter und niemand weiss es.
             */
            try {
                $info = $agent->call('pg.server.info', [], $this->actor());

                $this->line(match ($info['state'] ?? '') {
                    'ready' => sprintf('PostgreSQL läuft: %s.', $info['version'] ?? '?'),
                    'absent' => 'PostgreSQL ist nicht installiert. Der Knopf in „Einstellungen → '
                        .'Datenbankserver" holt es nach.',
                    'not_handed_over' => 'PostgreSQL läuft, aber die Rolle für das Panel fehlt noch: '
                        .Server::HANDOVER,
                    default => 'PostgreSQL: '.($info['reason'] ?? 'unklarer Zustand'),
                });
            } catch (AgentException $error) {
                $this->warn('Der Agent hat nicht geantwortet: '.$error->getMessage());
            }
        } else {
            // Ohne Mandantenklammer, und ausdrücklich: Auf der Kommandozeile ist
            // niemand angemeldet, und der Grundzustand der Klammer ist „nichts" —
            // die Warnung zählte sonst immer null.
            $bestand = $tenancy->withoutRestriction(
                static fn (): int => Database::query()->where('engine', DatabaseEngine::Postgres)->count(),
            );

            if ($bestand > 0) {
                $this->warn(sprintf(
                    '%d PostgreSQL-Datenbank(en) stehen im Bestand. Sie bleiben, wo sie sind, und ihre '
                    .'Zugänge funktionieren weiter — im Panel sind sie danach nicht mehr zu sehen.',
                    $bestand,
                ));
            }
        }

        $settings->savePostgres($an);

        $this->line($an
            ? 'PostgreSQL wird jetzt angeboten.'
            : 'PostgreSQL wird nicht mehr angeboten.');

        return self::SUCCESS;
    }

    /**
     * Wer den Aufruf ausgelöst hat — für das Protokoll des Agenten.
     *
     * @return array<string, string>
     */
    private function actor(): array
    {
        return ['source' => 'cli', 'command' => 'srvpanel:db'];
    }
}
