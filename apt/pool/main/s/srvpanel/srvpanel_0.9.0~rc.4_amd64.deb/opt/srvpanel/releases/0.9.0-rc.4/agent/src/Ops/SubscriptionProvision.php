<?php

declare(strict_types=1);

namespace SrvPanel\Agent\Ops;

use SrvPanel\Agent\AgentException;
use SrvPanel\Agent\Context;
use SrvPanel\Agent\DiskQuota;
use SrvPanel\Agent\Filesystem;
use SrvPanel\Agent\Guard;
use SrvPanel\Agent\Op;
use SrvPanel\Agent\WelcomePage;

/**
 * Legt die Systemseite eines Abonnements an: Gruppe, Systembenutzer,
 * Verzeichnisschema nach §4.5 und die Dateisystem-Quota.
 *
 * **Die Operation nimmt keinen Pfad entgegen — sie baut ihn.** Das ist die
 * wichtigste Entscheidung in dieser Datei. Übergeben wird der *Name* des
 * Abonnements, geprüft gegen eine Positivliste; der Pfad entsteht hier als
 * `/var/www/vhosts/<name>`. Damit gibt es kein `..`, keinen Symlink und keinen
 * absoluten Pfad, den ein Aufrufer unterschieben könnte. Eine Operation, die
 * einen Pfad annimmt und ihn danach prüft, ist eine Operation, deren Prüfung
 * irgendwann eine Lücke hat.
 *
 * **Der Benutzername wird nicht frei gewählt.** Er muss `p` gefolgt von
 * Ziffern sein. Ein Aufrufer, der sich `root`, `www-data` oder `srvpanel`
 * wünschen könnte, hätte über `useradd` einen Weg, ein bestehendes Konto zu
 * berühren — und über `setquota` einen Weg, ihm eine Quota zu setzen.
 *
 * **Warum die Wurzel root gehört und der Inhalt dem Kunden.** OpenSSH
 * verweigert ein Chroot, dessen Wurzel dem eingesperrten Benutzer gehört oder
 * für andere schreibbar ist — und zwar wortlos beim Verbindungsaufbau. Die
 * Zweiteilung aus §4.5 ist deshalb keine Vorsicht, sondern eine Vorgabe:
 * Wurzel `root:root 0755`, Inhalt `<benutzer>:<gruppe>`.
 *
 * **Der Lauf ist wiederholbar.** Ein zweiter Aufruf mit denselben Werten legt
 * nichts doppelt an und wirft nichts weg. Das ist die Voraussetzung dafür,
 * dass ein abgebrochener Vorgang wiederholt werden kann, ohne dass jemand
 * vorher von Hand aufräumt.
 */
final class SubscriptionProvision implements Op
{
    /** Die Wurzel aller Abonnements. Steht hier und kommt nicht von aussen. */
    public const VHOSTS = '/var/www/vhosts';

    /**
     * Das Verzeichnis, das später ausgeliefert wird (§4.5).
     *
     * Es steht als Konstante da, weil ab P3 der vhost darauf zeigt — und ein
     * Verzeichnisname, der an zwei Stellen getippt wird, ist ein
     * Verzeichnisname, der irgendwann an einer davon anders lautet.
     */
    public const DOCUMENT_ROOT = 'httpdocs';

    /**
     * Die Gruppe des ausgelieferten Verzeichnisses.
     *
     * Sie steht hier und nicht ein zweites Mal in {@see WebSiteApply}: Bis zum
     * 14. August 2026 standen `'www-data'` und `0750` an beiden Stellen, und
     * eine Änderung an einer davon wäre stillschweigend die Hälfte gewesen.
     */
    public const DOCUMENT_ROOT_GROUP = 'www-data';

    /**
     * Und seine Rechte — **mit setgid**.
     *
     * ## Warum das Bit dasteht
     *
     * `httpdocs` gehört `<benutzer>:www-data`, und **der Webserver kommt über
     * die Gruppe hinein**. Eine Datei, die beim Anlegen des Abonnements
     * entsteht, trägt deshalb `p1132:www-data 0640` und ist für ihn lesbar.
     *
     * Eine Datei aus dem Dateimanager trug bis hierher `p1132:p1132 0644` — die
     * Sandbox setzt auf die Gruppe des Abonnements, und keine Datei-Operation
     * fasste sie danach an. Lesbar war sie für den Webserver **nur über das
     * Weltbit** (`docs/53`, Befund 3).
     *
     * Das ging gut, bis jemand tut, wozu das Panel ausdrücklich einlädt: Er
     * setzt `0640` — dieselbe Angabe, die die Willkommensseite daneben trägt
     * und die dort funktioniert — und bekommt einen 403.
     *
     * > **Zwei Wege, die dieselbe Datei anlegen, müssen sie gleich anlegen —
     * > sonst ist die Rechteanzeige eine Auskunft über die Hälfte der
     * > Wahrheit.**
     *
     * ## Warum setgid und kein `chgrp` nach jedem Schreibvorgang
     *
     * Das Bit steht **einmal** am Verzeichnis und gilt für jeden, der darin
     * etwas anlegt: der Dateimanager, SFTP, ein Entpackvorgang — und auch der
     * Weg, den es noch nicht gibt. Ein `chgrp` müsste in zwölf Operationen
     * stehen, in SFTP noch einmal, und in der dreizehnten fehlte es.
     *
     * Neue Unterverzeichnisse erben das Bit mit, also trägt es der ganze Baum.
     *
     * **Es vergibt keine Rechte.** setgid an einem Verzeichnis bestimmt nur,
     * welche Gruppe neue Einträge bekommen; wer hineindarf, entscheiden
     * weiterhin `0750` und der Eigentümer.
     */
    public const DOCUMENT_ROOT_MODE = 0o2750;

    /**
     * Die Gruppe der Protokollverzeichnisse — `logs/` und `logs/<domain>`.
     *
     * Sie steht hier und in {@see WebSiteApply} nicht noch einmal, aus
     * demselben Grund wie {@see self::DOCUMENT_ROOT_GROUP}. **Und an ihr hängt
     * eine dritte Datei:** Solange `www-data` weder Eigentümer noch in dieser
     * Gruppe ist und das Weltbit fehlt, kommt kein Arbeiter von nginx in das
     * Verzeichnis — und die Rotation muss nginx neu laden, statt ihm nur
     * `USR1` zu schicken ({@see WebLogrotate}). `LogRotationTest` hält die drei
     * aneinander.
     */
    public const LOG_GROUP = 'adm';

    /** Und ihre Rechte — setgid aus demselben Grund wie oben. */
    public const LOG_MODE = 0o2750;

    /**
     * Das Verzeichnisschema aus §4.5.
     *
     * `%u` ist der Systembenutzer des Abonnements, `%g` seine Gruppe.
     *
     * **Jedes Verzeichnis des Kunden trägt setgid** — die Begründung steht bei
     * {@see self::DOCUMENT_ROOT_MODE}. `conf` ist ausgenommen, weil es root
     * gehört und der Kunde dort nichts anlegt.
     *
     * @var array<string, array{0: string, 1: string, 2: int}> Pfad => [Eigentümer, Gruppe, Rechte]
     */
    private const TREE = [
        self::DOCUMENT_ROOT => ['%u', self::DOCUMENT_ROOT_GROUP, self::DOCUMENT_ROOT_MODE],

        // Dieselbe Überlegung für die Protokolle: Sie gehören `adm`, damit ein
        // Betreiber sie lesen kann, ohne root zu sein. Ohne setgid trüge jede
        // Datei, die nginx dort anlegt, die Gruppe ihres Erzeugers.
        'logs' => ['%u', self::LOG_GROUP, self::LOG_MODE],

        // Hier ändert das Bit nichts — Eigentümer und Gruppe sind dieselben —,
        // und es steht trotzdem da: Eine Regel, die für „alle Verzeichnisse des
        // Kunden" gilt, muss beim nächsten Zuwachs des Schemas nicht neu
        // beurteilt werden. Eine, die für „die mit einer fremden Gruppe" gilt,
        // schon.
        'tmp' => ['%u', '%g', 0o2700],

        'conf' => ['root', 'root', 0755],

        // **Auch `.ssh` mit setgid, und das ist nachgesehen und nicht geraten.**
        // OpenSSH weist einen Zugang ab, wenn Verzeichnis oder Schlüsseldatei
        // für Gruppe oder Andere **schreibbar** sind — `safe_path()` prüft
        // `st_mode & 022`. Das setgid-Bit ist `02000` und fällt nicht darunter.
        '.ssh' => ['%u', '%g', 0o2700],

        // §5.5: Das Schema hält den Platz für Postfix/Dovecot frei, damit die
        // Mail-Stufe später nicht das Verzeichnis eines laufenden Abonnements
        // umbauen muss.
        'mail' => ['%u', '%g', 0o2700],
    ];

    /**
     * Die Verzeichnisse des Schemas, die **kein** DocumentRoot sein dürfen.
     *
     * Sie stehen hier und nicht im Panel, weil sie aus derselben Tabelle
     * kommen wie das Schema selbst: Wächst {@see self::TREE}, wächst diese
     * Liste mit. Ein Panel, das `logs`, `conf`, `tmp`, `.ssh` und `mail`
     * abgetippt hätte, wäre bei der ersten Erweiterung des Schemas falsch
     * geworden — und was daraus folgt, ist keine Kleinigkeit: Ein
     * DocumentRoot auf `logs` liefert die Zugriffsprotokolle des Kunden über
     * HTTP aus, eines auf `.ssh` seine Schlüssel.
     *
     * @return list<string>
     */
    public static function reservedDirectories(): array
    {
        return array_values(array_diff(array_keys(self::TREE), [self::DOCUMENT_ROOT]));
    }

    public static function name(): string
    {
        return 'subscription.provision';
    }

    public static function mutating(): bool
    {
        return true;
    }

    public function execute(array $args, Context $context): array
    {
        $name = self::subscriptionName($args['name'] ?? null);
        $user = self::systemUser($args['user'] ?? null);
        $quotaMb = DiskQuota::limit($args['quota_mb'] ?? null);

        $root = self::VHOSTS.'/'.$name;

        $context->progress(10, 'Gruppe und Systembenutzer');
        $created = $this->account($context, $user, $root);

        $context->progress(45, 'Verzeichnisse');
        $this->tree($root, $user);

        $context->progress(60, 'Willkommensseite');
        $welcome = $this->welcome($root.'/'.self::DOCUMENT_ROOT, $user);

        $context->progress(75, 'Quota');
        $quota = $this->quotaApply($context, $user, $quotaMb);

        $context->progress(100, 'fertig');

        return [
            'name' => $name,
            'user' => $user,
            'root' => $root,
            'document_root' => $root.'/'.self::DOCUMENT_ROOT,
            'created' => $created,
            'welcome' => $welcome,
            'quota' => $quota,
        ];
    }

    /**
     * Der Name des Abonnements — und damit der Verzeichnisname.
     *
     * Erlaubt sind Kleinbuchstaben, Ziffern, Punkt und Bindestrich, beginnend
     * und endend mit einem alphanumerischen Zeichen. Das deckt Domainnamen ab
     * und schliesst alles aus, was ein Pfad sein könnte: kein Schrägstrich,
     * kein Punkt am Anfang, kein `..`.
     */
    public static function subscriptionName(mixed $value): string
    {
        $name = Guard::string($value, 'name');

        if (! preg_match('/^[a-z0-9]([a-z0-9.\-]{0,61}[a-z0-9])?$/D', $name)) {
            throw AgentException::badRequest('Unzulässiger Name für ein Abonnement.', ['name' => $name]);
        }

        if (str_contains($name, '..')) {
            throw AgentException::badRequest('Unzulässiger Name für ein Abonnement.', ['name' => $name]);
        }

        return $name;
    }

    /**
     * Der Systembenutzer: `p` und Ziffern, sonst nichts.
     *
     * Die enge Form ist Absicht. Ein frei gewählter Name wäre ein Weg, über
     * `useradd`/`usermod` ein bestehendes Konto zu berühren — `root`,
     * `www-data`, `srvpanel` oder das Konto eines anderen Abonnements.
     * Ausserdem bleibt die Länge unter der Grenze, ab der `useradd` auf
     * manchen Systemen abweist.
     */
    public static function systemUser(mixed $value): string
    {
        $user = Guard::string($value, 'user');

        if (! preg_match('/^p[0-9]{4,9}$/D', $user)) {
            throw AgentException::badRequest(
                'Unzulässiger Systembenutzer — erwartet wird „p" und vier bis neun Ziffern.',
                ['user' => $user],
            );
        }

        return $user;
    }

    /**
     * Gruppe und Benutzer anlegen.
     *
     * `--no-user-group` und die eigene Gruppe zuerst: `useradd` legt sonst je
     * nach Distribution eine Gruppe mit demselben Namen an oder steckt den
     * Benutzer in `users` — und dann sähe jedes Abonnement die Dateien jedes
     * anderen, weil `0750` auf einer geteilten Gruppe nichts ausschliesst.
     *
     * Keine Login-Shell und kein Passwort: Der Zugang läuft über SFTP mit
     * Chroot (P6), nicht über eine Shell.
     *
     * @return bool Wurde das Konto in diesem Lauf angelegt?
     */
    private function account(Context $context, string $user, string $root): bool
    {
        if ($this->exists($user)) {
            return false;
        }

        $group = $context->stream('groupadd', ['--force', $user]);

        if (! $group->successful()) {
            throw AgentException::execFailed(
                'Gruppe konnte nicht angelegt werden.',
                ['user' => $user, 'stderr' => $group->stderr],
            );
        }

        // `--no-create-home`: Das Home ist die Chroot-Wurzel, und die muss
        // root gehören. Liesse man useradd sie anlegen, gehörte sie dem
        // Benutzer — und OpenSSH verweigerte das Chroot wortlos.
        $result = $context->stream('useradd', [
            '--gid', $user,
            '--no-user-group',
            '--home-dir', $root,
            '--no-create-home',
            '--shell', '/usr/sbin/nologin',
            '--comment', 'SrvPanel-Abonnement',
            $user,
        ]);

        if (! $result->successful()) {
            throw AgentException::execFailed(
                'Systembenutzer konnte nicht angelegt werden.',
                ['user' => $user, 'stderr' => $result->stderr],
            );
        }

        return true;
    }

    private function exists(string $user): bool
    {
        return posix_getpwnam($user) !== false;
    }

    /**
     * Das Verzeichnisschema anlegen — und bei jedem Lauf die Rechte
     * geraderücken.
     *
     * Auch für bestehende Verzeichnisse: Ein Abonnement, an dessen Rechten
     * jemand von Hand gedreht hat, kommt so beim nächsten Lauf zurück auf den
     * Stand aus §4.5. Das ist der Unterschied zwischen einem Schema, das
     * gilt, und einem, das einmal galt.
     */
    private function tree(string $root, string $user): void
    {
        self::applyTree($root, $user);
    }

    /**
     * Das Schema setzen — von aussen, und deshalb statisch.
     *
     * **Seit P8 Schritt 8 gibt es einen zweiten Aufrufer.** `backup.restore`
     * setzt nach dem Auspacken den Eigentümer über den ganzen Baum, und ein
     * rekursiver Griff ebnet dabei ein, was hier steht: `httpdocs` gehört
     * `%u:www-data`, `logs` gehört `%u:adm`, `conf` gehört `root:root`. Danach
     * käme der Webserver an das Dokumentenverzeichnis nicht mehr heran.
     *
     * > **Ein Schema, das eine Stelle kennt, wird von jedem rekursiven Griff
     * > eingeebnet — und der Schaden sieht aus wie ein Rechteproblem irgendwo
     * > anders.**
     *
     * Die Wiederherstellung ruft deshalb **diese** Stelle und baut das Schema
     * nicht nach: Eine zweite Aufzählung wäre die, die beim nächsten Zuwachs
     * von {@see self::TREE} veraltet.
     */
    /**
     * Eigentümer und Gruppe eines Bereichs des Schemas — oder `null`.
     *
     * **Sie steht hier, weil das Schema hier steht.** {@see self::applyTree()}
     * setzt es **an** den Verzeichnissen; was **darunter** liegt, geht
     * `BackupRestore::own()` an, und das braucht dieselbe Auskunft. Eine
     * zweite Aufzählung dort wäre die, die beim nächsten Zuwachs von
     * {@see self::TREE} veraltet.
     *
     * **Der Befund, der diese Methode ausgelöst hat** (P8, 17. September 2026):
     * Nach einer Wiederherstellung trugen die Dateien unter `httpdocs` die
     * primäre Gruppe des Benutzers statt `www-data`, und der Webserver konnte
     * sie nicht mehr lesen — gemessen `HTTP 403` an einer echten Domain. Das
     * Verzeichnis selbst war richtig; `applyTree()` hatte es zurückgeholt.
     *
     * > **Eine Behebung, die eine Ebene zu hoch ansetzt, sieht aus wie die
     * > Lösung des Problems, das sie beschreibt.**
     *
     * @param  string  $part  der erste Pfadteil unterhalb der Wurzel
     * @return array{0: string, 1: string}|null Eigentümer und Gruppe
     */
    public static function area(string $part, string $user): ?array
    {
        if (! array_key_exists($part, self::TREE)) {
            return null;
        }

        [$owner, $group] = self::TREE[$part];

        return [
            $owner === '%u' ? $user : $owner,
            $group === '%g' ? $user : $group,
        ];
    }

    public static function applyTree(string $root, string $user): void
    {
        Filesystem::directory($root, 'root', 'root', 0755);

        foreach (self::TREE as $part => [$owner, $group, $mode]) {
            Filesystem::directory(
                $root.'/'.$part,
                $owner === '%u' ? $user : $owner,
                $group === '%g' ? $user : $group,
                $mode,
            );
        }
    }

    /**
     * Die Willkommensseite für das erste DocumentRoot.
     *
     * Sie steht seit P4 in {@see WelcomePage} — jede weitere Domain bekommt
     * dieselbe Seite über `web.site.apply`, und zwei Fassungen davon wären
     * zwei Gelegenheiten, sie auseinanderlaufen zu lassen.
     */
    private function welcome(string $documentRoot, string $user): bool
    {
        return WelcomePage::into($documentRoot, $user);
    }

    /**
     * Ein Verzeichnis des Schemas anlegen.
     *
     * **Hier stand eine zweite Fassung von {@see Filesystem::directory()}** —
     * Zeile für Zeile dieselbe, bis auf den Kommentar. Aufgefallen ist sie beim
     * Setzen des setgid-Bits: Eine Änderung an der Rechtevergabe hätte an zwei
     * Stellen ankommen müssen, und die zweite hätte sie nicht bekommen.
     *
     * > **Zwei Fassungen derselben Regel sind zwei Gelegenheiten, sie
     * > auseinanderlaufen zu lassen — und die zweite ist die, die veraltet.**
     *
     * Die Sonderbehandlung einer fehlenden Gruppe (`adm` gibt es auf schlanken
     * Installationen nicht) steht dort mit derselben Begründung: Das
     * Verzeichnis gehört dann dem Benutzer allein — enger als vorgesehen, nicht
     * weiter.
     */
    /**
     * Die Dateisystem-Quota setzen.
     *
     * Die Mechanik steht in {@see DiskQuota} — dieselbe, die
     * `subscription.quota` benutzt, wenn ein Kontingent nachträglich geändert
     * wird. Eine zweite Fassung hier hiesse, dass zwei Wege dieselbe Grenze
     * setzen und einer davon irgendwann anders rechnet.
     *
     * @return array{enforced: bool, limit_mb: int, reason?: string}
     */
    private function quotaApply(Context $context, string $user, int $quotaMb): array
    {
        return DiskQuota::apply($context, $user, $quotaMb);
    }
}
