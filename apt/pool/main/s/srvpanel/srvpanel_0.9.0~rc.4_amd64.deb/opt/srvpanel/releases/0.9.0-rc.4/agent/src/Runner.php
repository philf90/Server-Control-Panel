<?php

declare(strict_types=1);

namespace SrvPanel\Agent;

use SrvPanel\Agent\Pg\Credentials;

/**
 * Die einzige Stelle, an der der Agent ein Programm startet.
 *
 * Vier Zusagen, die hier eingelöst werden und nirgends sonst:
 *
 * 1. **Positivliste mit absoluten Pfaden.** Aufrufer nennen einen logischen
 *    Namen („systemctl"), nie einen Pfad. Der Pfad wird nicht über $PATH
 *    gesucht — ein manipuliertes PATH-Element wäre bei einem Prozess als root
 *    der direkte Weg zu fremdem Code.
 * 2. **Keine Shell.** Argumente gehen als Array an proc_open. Es gibt keinen
 *    Punkt in diesem Programm, an dem aus Benutzereingaben eine
 *    Kommandozeile zusammengesetzt wird.
 * 3. **Feste Umgebung.** LC_ALL=C hält die Ausgabe in dem Format, das die
 *    Parser kennen. Auf einem deutsch eingestellten Server scheiterte das
 *    Auswerten sonst — und zwar still.
 * 4. **Gedeckelte Ausgabe und Zeitlimit.** Ein Programm mit endloser Ausgabe
 *    kann den Speicher des Agenten nicht füllen, ein hängendes nicht seine
 *    Prozesstabelle.
 */
final class Runner
{
    public const OUTPUT_MAX = 4 * 1024 * 1024;

    /** @var array<string,string> logischer Name => absoluter Pfad */
    private const PROGRAMS = [
        'systemctl' => '/usr/bin/systemctl',
        'systemd-run' => '/usr/bin/systemd-run',
        'journalctl' => '/usr/bin/journalctl',

        /*
         * **Dazugekommen am 6. September 2026 für A11**, und rein lesend:
         * `timedatectl show` gibt den Zustand des Zeitabgleichs als
         * Schlüssel-Wert-Zeilen. Gerufen wird es ausschliesslich mit `show`;
         * `set-timezone` und `set-ntp` gäbe es, und A11 ist eine Anzeige
         * (`docs/106 §9`).
         *
         * Gebraucht wird es für die drei Fragen, die anders nicht zu
         * beantworten sind: ob ein Zeitdienst installiert ist, ob er läuft und
         * ob die Uhr stimmt. **Die Zone des Servers gehört nicht dazu** — die
         * beantwortet `App\Support\Cron\ServerZone` seit P6, und ein zweiter
         * Leser derselben Quelle wäre der, der veraltet.
         */
        'timedatectl' => '/usr/bin/timedatectl',

        /*
         * A3, erster Wurf (`docs/109`). Vier Programme für zwei Fragen: was
         * lauscht, und was steht im Regelwerk.
         *
         * **`iptables` steht hier nicht, und das ist der Punkt.**
         * `/usr/sbin/iptables` ist ein alternatives-Symlink (gemessen,
         * `docs/81 §2.3s` M7) — die Antwort hinge daran, worauf er gerade
         * zeigt. Gefragt werden die Bauarten mit ihrem eigenen Namen; nur so
         * ist eine leere Antwort von der einen von einer vollen der anderen zu
         * unterscheiden (M10).
         *
         * **`ufw` und `firewall-cmd` fehlen auf den meisten Servern**, und das
         * ist kein Fehler: `run()` wirft dafür `NOT_FOUND`, und `SystemPorts`
         * macht daraus ein `null`.
         *
         * Die Pfade sind auf Ubuntu 24.04 gemessen. Ein Pfad, der auf einer
         * anderen Plattform woanders liegt, sähe hier aus wie „nicht
         * installiert" — deshalb prüft sie der Abnahmelauf auf dem Server
         * (`docs/109 §7`) und nicht dieser Kommentar.
         */
        // `run-parts --test` führt nichts aus — es druckt, **welche** Skripte
        // eines `cron.*`-Verzeichnisses liefen. Gefragt wird es, statt seine
        // Namensregeln nachzubauen: Sechs von zwölf Prüfkörpern übergeht es
        // wortlos (`docs/81 §2.3t` M2), und eine zweite Fassung dieser Regeln
        // wäre die, die veraltet.
        'run-parts' => '/usr/bin/run-parts',

        /*
         * **Dazugekommen am 27. September 2026 für „Platte voll"**, rein
         * lesend und nur als `stat -f`: Es liefert die Inodes einer Platte, und
         * PHP hat dafür keine Funktion. Volle Inodes lassen jede neue Datei mit
         * „No space left on device" scheitern, während die Belegung 7,5 % zeigt
         * (`docs/136 §3` M3).
         *
         * `stat` gehört zu coreutils und liegt auf jedem Debian und Ubuntu
         * unter diesem Pfad (gemessen mit `dpkg -S`). `df` sagte dasselbe mit
         * einer Kopfzeile zum Zerlegen; `stat -f -c` druckt genau die zwei
         * Zahlen und den Pfad.
         */
        'stat' => '/usr/bin/stat',
        'ss' => '/usr/bin/ss',
        'nft' => '/usr/sbin/nft',
        'iptables-legacy' => '/usr/sbin/iptables-legacy',
        'ufw' => '/usr/sbin/ufw',
        'firewall-cmd' => '/usr/bin/firewall-cmd',
        'nginx' => '/usr/sbin/nginx',
        'sshd' => '/usr/sbin/sshd',
        'php-fpm' => '/usr/sbin/php-fpm',

        // Je Version ein eigener Handler, und jeder steht einzeln hier.
        // Sie aus der Version zusammenzusetzen wäre bequemer und genau das,
        // was eine Positivliste nicht tun darf: Aus einem Wert einen Pfad zu
        // bauen ist der Vorgang, den sie verhindert. `PhpVersionCatalogTest`
        // prüft, dass zu jeder Version im Katalog eine Zeile hier gehört.
        'php-fpm8.1' => '/usr/sbin/php-fpm8.1',
        'php-fpm8.2' => '/usr/sbin/php-fpm8.2',
        'php-fpm8.3' => '/usr/sbin/php-fpm8.3',
        'php-fpm8.4' => '/usr/sbin/php-fpm8.4',
        'named-checkzone' => '/usr/bin/named-checkzone',
        'useradd' => '/usr/sbin/useradd',
        'userdel' => '/usr/sbin/userdel',
        'usermod' => '/usr/sbin/usermod',
        'groupadd' => '/usr/sbin/groupadd',
        // Dazugekommen mit subscription.remove. `userdel` nimmt die Gruppe
        // nicht mit, wenn sie nicht als „user private group" angelegt wurde —
        // und genau das ist sie hier nicht, weil useradd mit --no-user-group
        // läuft. Ohne groupdel bliebe je gelöschtem Abonnement eine Gruppe in
        // /etc/group stehen.
        'groupdel' => '/usr/sbin/groupdel',
        'setquota' => '/usr/sbin/setquota',
        'repquota' => '/usr/sbin/repquota',

        // **Dazugekommen am 2. September 2026 für A10.** `quotaon -p` ist die
        // einzige Frage, die beantwortet, ob die Quota **erzwungen** wird —
        // `repquota` beantwortet nur, ob eine Quotadatei lesbar ist, und geht
        // grün, sobald sie daliegt, auch wenn die Quota aus ist (`docs/81
        // §2.3o` M11). Gerufen wird es ausschliesslich mit `-p`; der Agent
        // schaltet damit nichts.
        'quotaon' => '/usr/sbin/quotaon',
        'apt-get' => '/usr/bin/apt-get',

        /*
         * **Dazugekommen am 26. August 2026 für A1 Schritt 8**, und rein
         * lesend: `apt-config dump` gibt apts **aufgelöste** Sicht auf seine
         * Einstellungen aus.
         *
         * Gebraucht wird es für eine Frage, die anders nicht zu beantworten
         * ist: Läuft die Automatik dieses Servers wirklich? Die eigene Datei
         * sagt darüber nichts — `/etc/apt/apt.conf.d` wird nach ASCII sortiert
         * gelesen, und die letzte Zuweisung gewinnt. Gemessen in diesem
         * Container: `20auto-upgrades` sagt für beide Teilschalter `1`, und die
         * Automatik ist trotzdem aus, weil `docker-disable-periodic-update` den
         * Hauptschalter auf `0` setzt.
         *
         * > **Eine Auskunft aus der eigenen Datei ist keine über den wirksamen
         * > Zustand.**
         *
         * Dieselbe Bauart wie `apt-get indextargets` für die Quellen: apt
         * fragen statt apt nachrechnen.
         */
        'apt-config' => '/usr/bin/apt-config',

        // **Lesend, und es beantwortet die Frage, die `apt-get` sonst raten
        // müsste:** Welche der Pakete einer PHP-Version liegen schon da? Bis
        // P5b hat `php.version.install` das am Handler abgelesen —
        // `/usr/sbin/php-fpm8.2` da, also alles da —, und das war ein
        // Stellvertreter für eine Paketfrage. Als `pgsql` in die
        // Erweiterungsliste kam, gingen die beiden auseinander, und niemand
        // hat es gemerkt, weil die Operation Erfolg meldete (docs/38 §24.2).
        //
        // Gefragt wird das Paketsystem und nicht `php-fpm -m`: Die Modulnamen
        // eines Pakets sind nicht sein Name — `php8.2-mysql` bringt `mysqli`,
        // `mysqlnd` und `pdo_mysql` mit und kein Modul namens `mysql`
        // (gemessen). Eine Zuordnung dafür wäre eine zweite Liste, die
        // veraltet.
        'dpkg-query' => '/usr/bin/dpkg-query',

        /*
         * **Dazugekommen am 26. August 2026 für A1 Schritt 4b**, und die
         * Erweiterung dieser Liste ist die erste Grenze dieses Projekts — sie
         * gehört begründet.
         *
         * Gebraucht wird `gpg` für **eine** Frage: Wann läuft der
         * Signaturschlüssel einer Paketquelle ab? Ein abgelaufener Schlüssel
         * bricht `apt-get update`, und weil das (M5) mit `0` endet, merkt es
         * niemand — das ist Abnahmepunkt 4 aus `docs/81 §4`.
         *
         * Aufgerufen wird ausschliesslich lesend, mit `--show-keys
         * --with-colons`, und **nie mit einem Pfad aus einem Formular**: Die
         * Pfade stammen aus `Signed-By:` der Quelldateien, die eingebetteten
         * Blöcke kommen über stdin.
         *
         * **Und es liegt auf allen vier Zielplattformen** — gemessen, nicht
         * angenommen: Die apt-Messrunde der CI fährt F3 auf Debian 12/13 und
         * Ubuntu 22.04/24.04, und F3 meldet „gpg fehlt" als Ausfall. Alle vier
         * Läufe sind grün.
         */
        'gpg' => '/usr/bin/gpg',
        'mysql' => '/usr/bin/mysql',
        'mysqldump' => '/usr/bin/mysqldump',

        // **P5b, und die Liste wächst um drei Programme und keine Vollmacht.**
        // Alle drei sind fassungsunabhängige Wrapper von
        // `postgresql-client-common`, die selbst entscheiden, welche
        // Serverfassung sie ansprechen — deshalb steht hier keine Zahl, anders
        // als bei php-fpm.
        //
        // **Was hier ausdrücklich nicht steht: `runuser`, `su`, `setpriv`,
        // `sudo`.** PostgreSQL bildet Unix-Kennungen auf Rollen ab, und der
        // erste Entwurf von docs/38 §6 wollte deshalb einen Kennungswechsel.
        // Ein Programm, das als root beliebige andere unter beliebiger Kennung
        // startet, wäre die weiteste Zeile dieser ganzen Liste — weiter als
        // `certbot`, der unten mit einer schwächeren Begründung gehen musste.
        // Gebraucht wird er auch nicht: Gibt es eine PostgreSQL-Rolle `root`,
        // kommt der Agent über `local all all peer` als Superuser durch, ohne
        // dass irgendeine Datei angefasst wird. `AgentIdentityTest` hält beides
        // fest.
        'psql' => '/usr/bin/psql',
        'pg_dump' => '/usr/bin/pg_dump',
        'pg_restore' => '/usr/bin/pg_restore',

        // **Zwei Werkzeuge von `postgresql-common`, und beide tun genau eine
        // Sache.** `pg_lsclusters` liest, welche Cluster es gibt; `pg_ctlcluster`
        // startet einen vorhandenen. Sie stehen hier, weil sich die Frage
        // „installiert, aber gestoppt" von „gar nicht installiert" ohne sie
        // nicht beantworten lässt — gemessen am 9. August 2026: Das
        // Socketverzeichnis fehlt in beiden Fällen (docs/38 §2.2d).
        //
        // **`pg_lsclusters` ist dabei selbst der Fühler.** Fehlt das Programm,
        // wirft der Runner `not_found`, und genau das heisst „PostgreSQL ist
        // nicht installiert". Eine Prüfung auf eine Datei wäre eine zweite
        // Fassung derselben Frage.
        //
        // Nicht `systemctl` für den Start: Der Unitname hängt an Fassung und
        // Clustername (`postgresql@16-main.service`), und ihn aus zwei Werten
        // zusammenzusetzen ist der Vorgang, den eine Positivliste verhindert.
        'pg_lsclusters' => '/usr/bin/pg_lsclusters',
        'pg_ctlcluster' => '/usr/bin/pg_ctlcluster',

        // **`certbot` stand hier und ist mit P4 wieder gegangen.** Er war für
        // TLS vorgesehen; gebaut wurde statt dessen ein eigener ACME-Client im
        // Agenten (`agent/src/Acme/`, Begründung in docs/32 §6). Ein Programm,
        // das der Agent als root starten darf und nie startet, ist
        // Angriffsfläche mit Erlaubnisschein — und `certbot` ist keine
        // beliebige Zeile: Seine Erneuerungsdateien dürfen Hooks nennen, die
        // bei jedem Lauf als root ausgeführt werden.
    ];

    private const ENVIRONMENT = [
        'PATH' => '/usr/sbin:/usr/bin:/sbin:/bin',

        // Ohne diese Zeile hält `apt-get` beim ersten Paket an, das eine
        // Rückfrage stellt — und wartet auf eine Eingabe, die von einem
        // Dienst ohne Terminal nie kommt. Das Zeitlimit beendet den Lauf dann
        // nach zehn Minuten mit einer Meldung, in der nichts von der
        // eigentlichen Ursache steht.
        'DEBIAN_FRONTEND' => 'noninteractive',
        'LC_ALL' => 'C',
        'LANG' => 'C',
        'HOME' => '/root',
        'TERM' => 'dumb',
    ];

    /**
     * Die einzigen Namen, die ein Aufrufer zur festen Umgebung ergänzen darf.
     *
     * **Eine Positivliste, weil die Umgebung dieselbe Angriffsfläche ist wie
     * die Kommandozeile.** `LD_PRELOAD` lädt eine fremde Bibliothek in einen
     * Prozess, der als root läuft; `PATH` entscheidet, welches Programm
     * startet; `IFS` ändert, wie eine Shell zerlegt. Ein `array_merge` mit dem,
     * was ein Aufrufer mitbringt, hätte all das geöffnet — deshalb steht hier
     * dieselbe Bauart wie bei {@see self::PROGRAMS}: Was nicht genannt ist,
     * gibt es nicht.
     *
     * **`PGPASSFILE` ist mit P5b dazugekommen und der einzige Eintrag**
     * (`docs/38 §13.4`). Er ist nötig geworden, weil eine befristete Rolle sich
     * über den Unix-Socket nur mit Passwort anmelden kann und `psql` keinen
     * Schalter für die Passwortdatei kennt — nur diese Variable. In der
     * Umgebung steht dabei der **Pfad**; das Passwort liegt in einer Datei mit
     * `0600` unter `/run` ({@see Credentials}).
     *
     * **Ohne diese Zeile stünde die Datei in `/root/.pgpass`**, weil `HOME`
     * oben gesetzt ist und `psql` sie dort von selbst liest. Das wäre der Weg
     * ohne jede Änderung hier — und der schlechtere: ein Passwort auf der
     * Platte statt im Arbeitsspeicher, an einem Ort, an dem der Betreiber eine
     * eigene Datei liegen haben kann, die wir überschrieben hätten.
     *
     * @var list<string>
     */
    public const ENVIRONMENT_ALLOWED = ['PGPASSFILE'];

    public function __construct(private readonly Journal $journal) {}

    /**
     * Steht dieses Programm auf der Positivliste?
     *
     * Für die Prüfungen, die den Katalog gegen die Liste halten — nicht für
     * den Betrieb: Wer ein Programm starten will, ruft {@see self::run()} auf
     * und bekommt dieselbe Antwort als Ausnahme.
     */
    public static function knows(string $program): bool
    {
        return isset(self::PROGRAMS[$program]);
    }

    /**
     * Der absolute Pfad eines Programms der Positivliste.
     *
     * **Für den einen Fall, in dem ein Programm nicht hier gestartet wird.**
     * `SrvPanel\Agent\Ops\SystemReboot` übergibt `systemctl` an
     * `systemd-run`, damit der Neustart den Agenten überlebt — das Programm
     * läuft dann in einer Unit mit der Umgebung von systemd, und ein blosser
     * Name würde dort über einen fremden `PATH` aufgelöst.
     *
     * Gebraucht wird also der absolute Pfad. Ihn dort hinzuschreiben wäre eine
     * **zweite Schreibweise** einer Zeile, die in {@see self::PROGRAMS} schon
     * steht — und das ist der Fehler, den dieses Repo am häufigsten bezahlt
     * hat: Beim Umziehen wird die eine nachgetragen und die andere vergessen.
     *
     * > **Zwei Listen, die dasselbe meinen, laufen auseinander — und keine von
     * > beiden ist der Ort, an dem man nachsieht.**
     *
     * **Es ist keine zweite Tür.** Wer den Pfad hat, hat damit nichts, was
     * {@see self::run()} nicht auch gäbe; die Prüfung ist dieselbe, und ein
     * unbekannter Name endet hier genauso als Ablehnung.
     */
    public static function path(string $program): string
    {
        $path = self::PROGRAMS[$program] ?? null;

        if ($path === null) {
            throw AgentException::denied(
                sprintf('%s steht nicht auf der Positivliste der Programme.', $program),
            );
        }

        return $path;
    }

    /**
     * Die feste Umgebung plus das, was der Aufrufer nennen darf.
     *
     * **Der Wert muss ein absoluter Pfad sein**, und das ist keine Vorsicht auf
     * Verdacht: Die einzige erlaubte Variable nennt eine Datei, und der Runner
     * läuft mit `/` als Arbeitsverzeichnis. Ein relativer Pfad zeigte damit auf
     * die Wurzel des Dateisystems und wäre in der Fehlersuche die falsche Spur.
     *
     * @param  array<string,string>  $extra
     * @return array<string,string>
     */
    private static function environment(array $extra): array
    {
        foreach ($extra as $name => $value) {
            if (! in_array($name, self::ENVIRONMENT_ALLOWED, true)) {
                throw AgentException::denied(
                    sprintf('%s steht nicht auf der Positivliste der Umgebungsvariablen.', $name),
                );
            }

            if (! str_starts_with($value, '/') || str_contains($value, "\0")) {
                throw AgentException::badRequest(
                    sprintf('%s muss ein absoluter Pfad sein.', $name),
                    ['name' => $name],
                );
            }
        }

        return array_merge(self::ENVIRONMENT, $extra);
    }

    /**
     * Führt ein Programm aus der Positivliste aus.
     *
     * **`$input` ist eine Zeichenkette und liegt damit vollständig im
     * Speicher.** Für SQL-Anweisungen ist das richtig; für eine Sicherung von
     * zwei Gigabyte wäre es der Weg, auf dem der Agent den Arbeitsspeicher des
     * Servers füllt. Dafür gibt es `$inputFile` — der Kernel liest die Datei
     * dann selbst, und im Agenten steht davon nichts.
     *
     * Dazugekommen mit P5 (`docs/36 §10`), aus einem Fund beim Bauen: Es ist
     * dieselbe Grenze wie auf der Ausgabeseite, wo {@see self::OUTPUT_MAX} bei
     * 4 MiB deckelt. Wer einen Dump durch dieses Rohr schickt, bekommt ihn
     * abgeschnitten zurück — und eine abgeschnittene Sicherung ist schlimmer
     * als keine, weil sie aussieht wie eine.
     *
     * @param  list<string>  $args
     * @param  null|callable(string,string):void  $onOutput  Erhält Ausgabezeilen, sobald sie anfallen
     * @param  null|string  $input  Standardeingabe als Zeichenkette — nur für Kleines
     * @param  null|callable():bool  $abort  Wird in der Warteschleife befragt; `true` beendet das Programm
     * @param  null|string  $inputFile  Standardeingabe aus einer Datei — für alles Grosse
     * @param  array<string,string>  $environment  Ergänzungen zur festen Umgebung; nur {@see self::ENVIRONMENT_ALLOWED}
     */
    public function run(
        string $program,
        array $args,
        int $timeout = 60,
        ?callable $onOutput = null,
        ?string $input = null,
        ?callable $abort = null,
        ?string $inputFile = null,
        array $environment = [],
    ): Result {
        $path = self::PROGRAMS[$program] ?? null;

        if ($path === null) {
            throw AgentException::denied(sprintf('Programm %s steht nicht auf der Positivliste.', $program));
        }

        if (! is_executable($path)) {
            throw new AgentException(
                AgentException::NOT_FOUND,
                sprintf('%s ist auf diesem System nicht installiert.', $program),
                ['path' => $path],
            );
        }

        foreach ($args as $i => $arg) {
            if (! is_string($arg) || str_contains($arg, "\0")) {
                throw AgentException::badRequest(sprintf('Argument %d ist keine gültige Zeichenkette.', $i));
            }
        }

        if ($input !== null && $inputFile !== null) {
            throw AgentException::badRequest('Standardeingabe entweder als Zeichenkette oder als Datei, nicht beides.');
        }

        // Der Pfad wird vom Aufrufer gebaut und nicht entgegengenommen (`Db\Dump`);
        // hier steht die Gegenprobe, dass es ihn gibt — sonst öffnete `proc_open`
        // die Standardeingabe still auf nichts, und das Programm liefe mit einer
        // leeren Eingabe erfolgreich durch.
        if ($inputFile !== null && ! is_file($inputFile)) {
            throw new AgentException(
                AgentException::NOT_FOUND,
                'Die Datei für die Standardeingabe gibt es nicht.',
                ['path' => $inputFile],
            );
        }

        $command = array_merge([$path], array_values($args));
        $environment = self::environment($environment);
        $descriptors = [
            0 => match (true) {
                $input !== null => ['pipe', 'r'],
                $inputFile !== null => ['file', $inputFile, 'r'],
                default => ['file', '/dev/null', 'r'],
            },
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $startedAt = microtime(true);
        $pipes = [];
        $process = proc_open($command, $descriptors, $pipes, '/', $environment);

        if (! is_resource($process)) {
            throw AgentException::execFailed(sprintf('%s ließ sich nicht starten.', $program));
        }

        if ($input !== null) {
            fwrite($pipes[0], $input);
            fclose($pipes[0]);
        }

        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);

        $output = ['stdout' => '', 'stderr' => ''];

        // Der Zusammensetzer der Zeilen — je Kanal ein eigener Rest.
        $lines = new Lines;
        $truncated = false;
        $deadline = $startedAt + $timeout;
        $timedOut = false;
        $aborted = false;

        while (true) {
            $read = array_filter([1 => $pipes[1], 2 => $pipes[2]], static fn ($r) => is_resource($r) && ! feof($r));

            if ($read === []) {
                break;
            }

            if (microtime(true) >= $deadline) {
                $timedOut = true;
                break;
            }

            // Der Abbruch wird in derselben Schleife geprüft wie das
            // Zeitlimit und danach genauso behandelt: erst SIGTERM, dann
            // SIGKILL. Ein Abbruch, der das Kind weiterlaufen ließe, wäre
            // keiner — er hätte nur die Ausgabe abgeschaltet.
            if ($abort !== null && $abort()) {
                $aborted = true;
                break;
            }

            $write = null;
            $except = null;
            $ready = @stream_select($read, $write, $except, 0, 200000);

            if ($ready === false) {
                break;
            }

            foreach ($read as $number => $pipe) {
                $chunk = fread($pipe, 65536);
                if ($chunk === false || $chunk === '') {
                    continue;
                }

                $channel = $number === 1 ? 'stdout' : 'stderr';

                if (strlen($output[$channel]) < self::OUTPUT_MAX) {
                    $output[$channel] .= $chunk;
                    if (strlen($output[$channel]) > self::OUTPUT_MAX) {
                        $output[$channel] = substr($output[$channel], 0, self::OUTPUT_MAX);
                        $truncated = true;
                    }
                } else {
                    $truncated = true;
                }

                /*
                 * **Eine Stückgrenze ist keine Zeilengrenze.** Hier stand
                 * `explode("\n", rtrim($chunk, "\n"))`, und `rtrim` schneidet
                 * nur hinten: Endete ein Stück ohne seinen Umbruch, begann das
                 * nächste damit, und heraus fiel eine leere Zeile — oder, wenn
                 * die Grenze mitten im Text lag, eine zerrissene. Gemessen am
                 * 28. August 2026 gegen echtes apt: 320 Rahmenzeilen gegen 317
                 * wirkliche ({@see Lines}, Befund 4 aus `docs/86`).
                 */
                if ($onOutput !== null) {
                    foreach ($lines->feed($channel, $chunk) as $line) {
                        $onOutput($channel, $line);
                    }
                }
            }
        }

        if ($timedOut || $aborted) {
            proc_terminate($process, SIGTERM);
            usleep(300000);
            $status = proc_get_status($process);
            if ($status['running']) {
                proc_terminate($process, SIGKILL);
            }
        }

        foreach ([$pipes[1], $pipes[2]] as $pipe) {
            if (is_resource($pipe)) {
                fclose($pipe);
            }
        }

        $code = proc_close($process);
        $duration = microtime(true) - $startedAt;

        // -1 ist kein Rückgabecode, den ein Programm liefern kann: Er heißt,
        // dass jemand anderes den Kindprozess vor proc_close geerntet hat —
        // ein SIGCHLD-Handler im selben Prozess etwa. Das als „Programm
        // fehlgeschlagen" durchzureichen, hat einmal eine halbe Stunde
        // gekostet; es ist ein Fehler im Agenten und sagt das jetzt auch.
        if ($code === -1 && ! $timedOut && ! $aborted) {
            $this->journal->write('statusverlust', ['command' => $command]);

            throw AgentException::execFailed(sprintf(
                'Der Rückgabecode von %s ging verloren — ein Signalbehandler hat den Kindprozess geerntet.',
                $program,
            ));
        }

        /*
         * **Was ohne abschliessenden Umbruch endete, geht nicht verloren.**
         * {@see Lines} hält den Rest zurück, bis ein Umbruch kommt — kommt
         * keiner mehr, ist er trotzdem eine Zeile. Ohne das fiele ausgerechnet
         * die letzte weg, und bei `apt-run` steht dort das Urteil.
         */
        if ($onOutput !== null) {
            foreach (['stdout', 'stderr'] as $channel) {
                $rest = $lines->flush($channel);

                if ($rest !== null) {
                    $onOutput($channel, $rest);
                }
            }
        }

        $this->journal->command($command, $timedOut || $aborted ? null : $code, $duration);

        if ($timedOut) {
            throw new AgentException(
                AgentException::TIMEOUT,
                sprintf('%s hat das Zeitlimit von %d s überschritten.', $program, $timeout),
                ['program' => $program],
            );
        }

        if ($aborted) {
            throw new AgentException(
                AgentException::CANCELLED,
                sprintf('%s wurde abgebrochen.', $program),
                ['program' => $program],
            );
        }

        return new Result($code, $output['stdout'], $output['stderr'], $truncated, $duration);
    }

    /** @return array<string,string> */
    public static function programs(): array
    {
        return self::PROGRAMS;
    }
}
