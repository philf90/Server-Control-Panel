<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Enums\SubscriptionStatus;
use App\Models\Account;
use App\Models\Announcement;
use App\Models\Subscription;
use App\Support\Audit\Impersonation;
use App\Support\Authorization\AdminAbility;
use App\Support\Brand\Logo;
use App\Support\Diagnose\Checks\MaintenanceWindow;
use App\Support\Diagnose\PendingFindings;
use App\Support\Operations\RunningBand;
use App\Support\Panel\Source;
use App\Support\Passwords\Policy;
use App\Support\Settings\Settings;
use App\Support\Time\Clock;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\ViewErrorBag;
use Inertia\Middleware;

final class HandleInertiaRequests extends Middleware
{
    protected $rootView = 'app';

    /**
     * Alle Meldungen eines Feldes und nicht nur die erste.
     *
     * ## Der Fehler, den `report()` nicht sehen konnte
     *
     * Inertias Laravel-Anbindung bildet den Fehlerbeutel auf
     * `Feld => erste Meldung` ab. Ein `ValidationException::withMessages([
     * 'path' => [$zahl, $grund1, $grund2]])` kommt damit als **eine**
     * Zeichenkette im Browser an — der Rest fällt weg, bevor die Seite ihn
     * sieht.
     *
     * Gemessen auf `cloudsrv24` am 15. August 2026 (`docs/55`, Befund 12): Die
     * Mehrfachauswahl meldete „Von 3 Einträgen sind 2 entfernt." und **keinen
     * einzigen Grund**. Bei sechs geschützten Verzeichnissen dasselbe: die
     * Zahl, und sechsmal Schweigen darüber, woran es lag.
     *
     * **Es traf nicht nur die Mehrfachauswahl.** Der Mehrfach-Upload aus
     * Schritt 5e baut seine Rückmeldung genauso — die Zeile je Datei ist seit
     * dem ersten Tag unsichtbar gewesen. Ihr Wächter liest den Quelltext des
     * Controllers und konnte das nicht sehen.
     *
     * > **Eine Meldung, die der Controller schreibt, ist damit noch keine, die
     * > jemand liest.**
     *
     * Die Zahl allein ist dabei die schlechtere Hälfte: Sie sagt, dass etwas
     * schiefging, und verschweigt was — und der Kunde kann nichts daraus
     * machen.
     *
     * @return object Ein Wörterbuch `Feld => Sätze`, mit `\n` verbunden.
     */
    public function resolveValidationErrors(Request $request): object
    {
        $beutel = $request->session()->get('errors');

        if (! $beutel instanceof ViewErrorBag) {
            return (object) [];
        }

        /*
         * **Verbunden und nicht verschachtelt.** Ein Feld könnte auch eine
         * Liste zurückgeben; dann müsste jede Stelle, die Fehler liest, mit
         * beiden Formen rechnen — und die eine, die es vergisst, zeigt gar
         * nichts. Ein Zeilenumbruch trägt dieselbe Auskunft und bleibt eine
         * Zeichenkette.
         */
        $verbunden = [];

        /*
         * Von Hand statt über `collect()->map()`: Die Sammlung kennt den Typ
         * ihrer Schlüssel hier nicht, und eine Typangabe, die das behauptet,
         * wäre eine Behauptung über fremden Code. Eine Schleife sagt dasselbe
         * ohne sie.
         *
         * **`toArray()` und nicht `messages()`.** `getBag()` liefert die
         * Schnittstelle `Contracts\Support\MessageBag`, und die kennt
         * `messages()` nicht — das ist eine Methode der konkreten Klasse
         * dahinter. Zur Laufzeit ginge beides, weil dort immer diese Klasse
         * steht; das ist aber eine Zusage, die die Schnittstelle nicht macht.
         *
         * > **Eine Methode, die es zur Laufzeit gibt, steht deshalb noch nicht
         * > im Vertrag.**
         */

        /** @var array<string, list<string>> $meldungen */
        $meldungen = $beutel->getBag('default')->toArray();

        foreach ($meldungen as $feld => $saetze) {
            $verbunden[$feld] = implode("\n", $saetze);
        }

        return (object) $verbunden;
    }

    /**
     * Was auf jeder Seite verfügbar ist.
     *
     * Der Quellenlink gehört dazu, weil er auf jeder Seite steht — die Auflage
     * aus Abschnitt 13 der AGPL gilt für die Oberfläche, nicht für eine
     * Unterseite davon.
     *
     * ## Jeder Eintrag ist ein Verschluss, ausnahmslos
     *
     * Die Regel steht seit A14 in den Kommentaren einzelner Einträge und galt
     * seit B4 für alle (`docs/129 §8`). Der Grund ist gemessen
     * (`docs/103 §1` M5): **Ein fertiger Wert in `share()` läuft bei jeder
     * Anfrage, auch bei einer, die ihn gar nicht mitschickt. Ein Verschluss
     * läuft nur, wenn er gesendet wird.**
     *
     * **Was das bis zum 21. September 2026 gekostet hat**, gemessen an einem
     * Kundenkonto auf `/` mit `X-Inertia-Partial-Data: subscriptions`:
     *
     * | | Abfragen | davon für `account` |
     * |---|---|---|
     * | voller Besuch | 11 | 1 |
     * | partielles Nachladen | 10 | **1** |
     *
     * Die zweite Zeile ist der Befund: `has_active_subscription` fragte die
     * Datenbank für eine Eigenschaft, die die Antwort nicht enthält. Ein Admin
     * sah davon nichts — bei ihm bricht `isAdmin() ||` die Auswertung ab, und
     * genau deshalb ist der Prüfkörper von `SharedClosureTest` ein Kunde.
     *
     * > **Ein Prüfkörper, der im Fehlerfall dasselbe zeigt wie im Erfolgsfall,
     * > misst nicht.**
     *
     * Billige Einträge sind mitgegangen, obwohl sie nichts kosten — eine
     * Ausnahmeliste wäre so gut wie das Gedächtnis dessen, der sie pflegt, und
     * die erste teure Zeile, die jemand in einen „billigen" Eintrag schreibt,
     * steht dann still in jeder Anfrage.
     *
     * @return array<string,mixed>
     */
    public function share(Request $request): array
    {
        $account = $request->user();
        $settings = app(Settings::class);
        $logo = app(Logo::class);

        return array_merge(parent::share($request), [
            /*
             * **Eine fertige Adresse und keine Zutaten.** Hier standen
             * `repository` und `commit`, und die Vorlage setzte daraus den Link
             * zusammen — eine zweite Fassung der Regel, und zwar in einem
             * Template. {@see Source::url()} entscheidet jetzt, und die
             * Oberfläche zeigt nur noch an.
             */
            'source' => fn (): array => [
                'url' => Source::url(),
                'version' => config('app.version'),
            ],

            // Nur, was die Oberfläche wirklich braucht.
            //
            // Nicht das ganze Konto: Ein Modell, das man hierher reicht,
            // wächst mit der Zeit um Felder, die niemand angesehen hat — und
            // steht dann als JSON im Quelltext jeder Seite. Passwort-Hash und
            // 2FA-Geheimnis wären zwar über $hidden ausgenommen, aber die
            // nächste Spalte ist es nicht.
            'account' => fn (): ?array => $account instanceof Account ? [
                'name' => $account->name,
                'email' => $account->email,
                'type' => $account->type->value,
                'is_admin' => $account->isAdmin(),

                /*
                 * Hat dieses Konto ein benutzbares Abonnement?
                 *
                 * **Wofür.** Der Menüpunkt „Domains" steht bei einem Kunden
                 * erst da, wenn es einen Ort gibt, an dem eine Domain entstehen
                 * kann. Ohne aktives Abonnement führte er auf eine leere Liste
                 * ohne Knopf — eine Sackgasse mit Einladung.
                 *
                 * **Warum die Antwort hierher gehört.** Das Menü steht auf
                 * jeder Seite; jede einzelne müsste die Frage sonst selbst
                 * beantworten, und die meisten täten es nicht. Es ist keine
                 * Autorisierung — die sitzt an der Route (`can:viewAny`) —,
                 * sondern dieselbe Auskunft wie `is_admin` daneben: welcher Weg
                 * überhaupt einer ist.
                 *
                 * Für den Betreiber ohne Abfrage `true`: Er sieht die Liste
                 * immer, und eine Zählung über alle Abonnements bei jedem
                 * Seitenaufruf wäre für eine Antwort bezahlt, die feststeht.
                 */
                'has_active_subscription' => $account->isAdmin()
                    || Subscription::query()
                        ->whereIn('id', $account->accessibleSubscriptionIds())
                        ->whereIn('status', SubscriptionStatus::usableValues())
                        ->exists(),
            ] : null,

            /*
             * **Was der Betrachter auf diesem Server darf** — A9 Schritt 5.
             *
             * Die Navigation kam bis hierher aus dem **Kontotyp**, und das war
             * richtig, solange jeder Admin alles durfte. Seit Schritt 2 lösen
             * die Fähigkeiten über die Rolle auf: Ein Administrator sah sieben
             * Menüpunkte, die ihm alle einen 403 gaben.
             *
             * > **Wer eine Aktion zeigt, fragt vorher dieselbe Policy, die sie
             * > später abweist.**
             *
             * Gefragt wird `$account->can()` und damit dasselbe Gate, an dem
             * die Route hängt. Ein `v-if` auf die Rolle im Menü wäre die zweite
             * Fassung der Policy, und die zweite ist die, die veraltet.
             *
             * ## Warum der Schlüssel `abilities` heisst und nicht `can`
             *
             * `can` ist vergeben: **Neun Seiten** schicken eine eigene
             * `can`-Ablage — „was darf ich mit *diesem* Objekt". Seitenwerte
             * überschreiben geteilte, und ein geteiltes `can` wäre auf genau
             * diesen neun Seiten fort. Das Menü verlöre dort seine Einträge,
             * und zwar nur dort.
             *
             * > **Ein geteilter Schlüssel, den eine Seite auch benutzt, ist auf
             * > dieser Seite kein geteilter Schlüssel mehr — und der Ausfall
             * > sieht aus wie ein Rechteproblem.**
             *
             * Die beiden sind auch inhaltlich verschieden: `can` beantwortet
             * eine Frage über ein Objekt, `abilities` eine über den Server.
             */
            'abilities' => fn (): array => $account instanceof Account ? $this->abilities($account) : [],

            // „Anmelden als" muss auf jeder Seite sichtbar sein (§6.3). Ein
            // Admin, der vergisst, in wessen Sicht er ist, tut sonst im Namen
            // eines Kunden Dinge, die er für seine eigenen hält.
            'impersonation' => fn (): ?array => $this->impersonation($request),

            /*
             * Die Ankündigungen des Betreibers (A14, `docs/103 §7`).
             *
             * **Als Verschluss und nicht als fertiger Wert, und das ist
             * gemessen** (`docs/81 §2.3q` M5). Ein fertiger Wert in `share()`
             * wird auch bei einem partiellen Nachladen berechnet, das ihn gar
             * nicht mitschickt — gezählt an den Abfragen: voller Besuch 2,
             * partielles Nachladen 1, und die eine war die des fertigen Werts.
             *
             * > **Ein fertiger Wert in `share()` läuft bei jeder Anfrage, auch
             * > bei einer, die ihn gar nicht mitschickt. Ein Verschluss läuft
             * > nur, wenn er gesendet wird.**
             *
             * Das ist hier nicht theoretisch: Die Übersichtsseite lädt mit
             * ihrem Selbstlauf alle dreissig Sekunden `only: ['tiles']` nach.
             * Ohne den Verschluss liefe die Abfrage jedes Mal für eine Antwort,
             * die der Server verwirft.
             *
             * Dieselbe Form wie `flash` daneben, und aus demselben Grund.
             */
            'announcements' => fn (): array => $account instanceof Account
                ? Announcement::bannerRows(Announcement::visibleTo($account))
                : [],

            /*
             * Die Zahl fürs Abzeichen am Menüpunkt „Updates" (`docs/907`).
             *
             * **Ein Verschluss aus demselben Grund wie die Ankündigungen
             * darüber** — gemessen an `/services`: voller Aufbau 3 Abfragen,
             * partielles Nachladen 2. Ein fertiger Wert liefe auch bei dem
             * partiellen mit, und das kostet dort 2,7 ms insgesamt.
             *
             * **Und er trägt die Fähigkeit seiner Route.** Der Menüpunkt steht
             * auf `inspect-server`; ein Abzeichen, das weiter reicht als die
             * Seite dahinter, wäre eine Auskunft an jemanden, der sie nicht
             * nachsehen darf.
             *
             * **`null` heisst „nicht nachgesehen" und nicht „nichts zu tun".**
             * {@see Settings::pendingUpdates()} begründet den Unterschied; die
             * Leiste zeigt bei `null` kein Abzeichen.
             */
            'pendingUpdates' => fn (): ?int => $account instanceof Account
                && $account->can(AdminAbility::INSPECT_SERVER)
                    ? app(Settings::class)->pendingUpdates()
                    : null,

            /*
             * Die auffälligen Befunde der Bestandsdiagnose — dieselbe Form wie
             * oben und eine andere Bauart.
             *
             * **Hier wird gezählt und nicht abgelegt**, und das ist gemessen:
             * Die Zählung kostet warm 0,073 ms, ein abgelegter Wert aus
             * `settings` 0,211 (`docs/910 §2` M8). Eine Ablage wäre langsamer
             * als ihre Quelle — und dazu eine zweite Fassung derselben
             * Wahrheit.
             *
             * **Ein Verschluss und kein fertiger Wert**, wie bei allem hier:
             * Ein fertiger liefe auch bei einem partiellen Nachladen, das ihn
             * gar nicht mitschickt (`docs/103`).
             */
            'pendingFindings' => fn (): ?int => $account instanceof Account
                && $account->can(AdminAbility::INSPECT_SERVER)
                    ? app(PendingFindings::class)->count()
                    : null,

            /*
             * Der Wartungsmodus als Band (`docs/911`).
             *
             * **`operate-server` und nicht `inspect-server`**, und das folgt
             * aus dem Zweck: Das Band erinnert, und eine Erinnerung wirkt nur
             * bei dem, der handeln kann. Wer zusieht, kann die Wartung nicht
             * beenden; für ihn wäre dasselbe Band eine Erklärung, und die ist
             * ein anderes Merkmal.
             *
             * **Es steht auf jeder Seite, und deshalb liest es die Ablage.**
             * `web.maintenance.state` gibt es seit dem 12. September, aber ein
             * Sockelaufruf je Seitenaufbau wäre der Fehler, den `docs/904`
             * für `/updates` gerade behoben hat.
             *
             * **Der Name ist nicht `maintenance`, und das ist gemessen:**
             * `MaintenanceController` gibt seiner Seite eine Eigenschaft
             * dieses Namens, und Seitenwerte überschreiben geteilte. Auf
             * `/maintenance` — der einzigen Seite, auf der man den Modus
             * ausschaltet — wäre das Band damit fort. `SharedPropTest` hat es
             * gemeldet, bevor es jemand gesehen hat; derselbe Fehler wie `can`
             * gegen `abilities` (`docs/82`) und `errors` (`docs/904`).
             *
             * > **Ein geteilter Schlüssel, den eine Seite auch benutzt, ist auf
             * > genau dieser Seite fort — und der Ausfall liest sich wie ein
             * > Rechteproblem.**
             *
             * Den Abgleich zwischen Ablage
             * und Datei macht einmal pro Nacht
             * {@see \App\Support\Diagnose\Checks\MaintenanceFlag}.
             */
            'maintenanceBand' => fn (): ?array => $account instanceof Account
                && $account->can(AdminAbility::OPERATE_SERVER)
                    ? self::maintenanceBand(app(Settings::class)->maintenance())
                    : null,

            // Die Passwortrichtlinie steht auf jeder Seite bereit, weil ein
            // Passwortfeld überall auftauchen kann — beim Anlegen eines
            // Kunden, beim Ändern des eigenen, später beim Zurücksetzen. Sie
            // hier zu teilen ist billiger als jede Seite daran zu erinnern,
            // und sie kommt aus derselben Klasse wie die Validierung: Was der
            // Browser als Prüfliste zeigt, ist damit keine Behauptung über die
            // Regeln, sondern die Regeln.
            /*
             * Die Marke des Betreibers für die Oberfläche (B6).
             *
             * **Farbe und Titel stehen nicht hier** — die setzt
             * `app.blade.php`, weil beides vor dem ersten Zeichnen feststehen
             * muss. Hier steht, was Vue zeigt: Name, Logo, Fusszeile.
             *
             * **Ein Verschluss wie alles hier.** Die Marke kommt aus
             * `settings`, also aus der Datenbank; ein fertiger Wert liefe bei
             * jedem partiellen Nachladen mit, das ihn gar nicht mitschickt
             * (`docs/103 §1` M5).
             *
             * `logo` ist eine **Adresse und kein Dateiname**: Die Seite soll
             * nicht wissen, wie die Ablage heisst, und der Name allein liesse
             * offen, woher man das Bild bekommt.
             */
            'brand' => function () use ($settings, $logo): array {
                $marke = $settings->brand();

                return [
                    'name' => $marke->name,
                    'footer' => $marke->footer,
                    'logo' => $logo->path($marke->logo) === null ? null : route('branding.logo'),
                ];
            },

            'passwordPolicy' => fn (): array => [
                'minimum' => Policy::MINIMUM_LENGTH,
                'requirements' => Policy::requirements(),
            ],

            /*
             * **Jeder Schlüssel, den ein Controller schreibt, steht hier.**
             * `error` fehlte bis zum 17. August 2026, und damit fielen sieben
             * Meldungen aus vier Controllern lautlos aus — darunter „Zertifikat
             * abgewiesen" und „Der Versand ist gescheitert" (`docs/59`,
             * Befund 13). `Settings/Mail.vue` las den Schlüssel sogar und
             * renderte ihn; getragen hat ihn niemand.
             *
             * > **Ein Schreiber und ein Leser machen keinen Kanal. Dazwischen
             * > muss jemand tragen.**
             *
             * `FlashChannelTest` prüft beide Richtungen.
             */
            /*
             * **Der Streifen der laufenden Vorgänge (B8).**
             *
             * Er steht auf **jeder** Seite und überlebt damit jeden
             * Seitenwechsel — das ist Entscheidung 2 aus `docs/92 §4`. Eine
             * Seiten-Eigenschaft müsste jede der 58 Seiten durchreichen, und
             * die erste, die es vergisst, fällt niemandem auf.
             *
             * **Ein Verschluss wie alles hier**: Der Klient lädt ihn im Takt
             * mit `only: ['runningOperations']` nach, und ein fertiger Wert
             * liefe bei jeder anderen Anfrage mit (`docs/103 §1` M5).
             *
             * Wen er zeigt und wie lange, entscheidet {@see RunningBand} und
             * nicht diese Zeile — drei Bedingungen mit je einer Begründung
             * gehören nicht in eine Kette in der Mittelschicht.
             */
            'runningOperations' => fn (): array => app(RunningBand::class)->rows(
                $account instanceof Account ? $account : null,
                now(),
            ),

            'flash' => fn (): array => [
                'notice' => fn () => $request->session()->get('notice'),
                'success' => fn () => $request->session()->get('success'),
                'error' => fn () => $request->session()->get('error'),
                'recoveryCodes' => fn () => $request->session()->get('recoveryCodes'),

                /*
                 * **Der Klartext einer frisch angelegten Zugangsmarke (B7).**
                 * Er steht genau einmal auf dem Bildschirm und nirgends in der
                 * Ablage — derselbe Weg wie bei den Wiederherstellungscodes
                 * daneben und aus demselben Grund: Was man wiederzeigen kann,
                 * kann man auch mitlesen.
                 */
                'apiToken' => fn () => $request->session()->get('apiToken'),
            ],
        ]);
    }

    /**
     * Die Adminfähigkeiten des Betrachters, jede mit ihrer Antwort.
     *
     * **Aus der Registratur und nicht aus einer Liste hier.** Eine Fähigkeit,
     * die {@see AdminAbility::abilities()} dazubekommt, steht damit sofort auch
     * in der Ablage — sonst wäre dies die Stelle, an der jemand sie nachtragen
     * müsste und es vergisst.
     *
     * **Für einen Kunden sind alle `false`, und das ist kein Sonderfall.**
     * `Account::fulfils()` fragt beide Achsen; ein Kundenkonto erfüllt keine
     * Adminrolle. Die Ablage steht trotzdem da — eine fehlende Ablage und eine
     * mit lauter `false` müssen für die Oberfläche dasselbe bedeuten, sonst
     * hängt an ihrem Unterschied irgendwann eine Bedingung.
     *
     * @return array<string, bool>
     */
    private function abilities(Account $account): array
    {
        $abilities = [];

        foreach (array_keys(AdminAbility::abilities()) as $ability) {
            $abilities[$ability] = $account->can($ability);
        }

        return $abilities;
    }

    /**
     * Läuft gerade ein „Anmelden als"? Und wenn ja, wer hat es begonnen?
     *
     * @return array<string, mixed>|null
     */
    private function impersonation(Request $request): ?array
    {
        if (! $request->hasSession()) {
            return null;
        }

        $adminId = $request->session()->get(Impersonation::SESSION_KEY);

        if (! is_numeric($adminId)) {
            return null;
        }

        $admin = Account::query()->find((int) $adminId);

        return [
            'active' => true,
            'admin' => $admin->name ?? 'unbekannt',
        ];
    }

    /**
     * Was das Band über den Wartungsmodus sagt — oder `null`, wenn nichts.
     *
     * **Umgerechnet wird hier und nicht auf der Seite.** Abgelegt ist UTC;
     * was hinausgeht, ist Ortszeit über {@see Clock}, und zwar mit
     * `labelAt()` **je Zeitpunkt** und nicht `label()`: Berlin heisst im
     * Januar anders als im Juli, und beide Zeitpunkte können auf verschiedenen
     * Seiten einer Umstellung liegen.
     *
     * > **Eine Zonenangabe, die für „jetzt" gilt, gehört nicht neben einen
     * > Zeitpunkt, der woanders liegt.**
     *
     * `overdue` wird gerechnet und nicht abgelegt — derselbe Grund wie bei der
     * nächsten Fälligkeit eines Cronjobs (`docs/108`): Ein Wert, der aus
     * „jetzt" folgt und abgelegt wird, ist ab dem nächsten Augenblick falsch.
     *
     * @param  array{enabled: bool, until: null|string, since: null|string}  $stand
     * @return array{since: null|string, since_zone: null|string, until: null|string, until_zone: null|string, overdue: bool}|null
     */
    private static function maintenanceBand(array $stand): ?array
    {
        if (! $stand['enabled']) {
            return null;
        }

        $until = $stand['until'];

        return [
            'since' => Clock::minute($stand['since']),
            'since_zone' => Clock::labelAt($stand['since']),
            'until' => Clock::minute($until),
            'until_zone' => Clock::labelAt($until),
            'overdue' => $until !== null && self::isPast($until),
        ];
    }

    /**
     * Liegt dieser UTC-Zeitpunkt hinter uns?
     *
     * Ein unlesbarer Wert ist **nicht** überschritten: „nicht lesbar" ist etwas
     * anderes als „vorbei", und wer das eine als das andere meldet, schickt den
     * Betreiber zum Ausschalten, wo eine Zeile in der Tabelle kaputt ist —
     * dieselbe Unterscheidung, die {@see MaintenanceWindow}
     * in ihrem Kopf begründet.
     */
    private static function isPast(string $utc): bool
    {
        try {
            return CarbonImmutable::parse($utc, 'UTC')->isPast();
        } catch (\Throwable) {
            return false;
        }
    }
}
