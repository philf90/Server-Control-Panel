<?php

declare(strict_types=1);

namespace SrvPanel\Agent;

use SrvPanel\Agent\Acme\HttpChallenge;
use SrvPanel\Agent\Diagnose\Statements;

/**
 * Der Wartungsmodus — die Wache im Server-Block und die Datei, die sie schaltet
 * (A12, `docs/101 §3`).
 *
 * ## Eine Datei und kein Rundlauf
 *
 * Geschaltet wird das Anlegen und Löschen **einer** Datei; die Vhost-Dateien
 * bleiben unberührt. Damit gibt es keine Warteschlange, keine halb umgestellten
 * Domains und keinen Zustand, der zwischen zwei Domains auseinanderlaufen kann.
 *
 * Der Block weiss dabei **nicht**, ob Wartung ist — er weiss nur, was er sagen
 * soll, falls sie es ist. Die Entscheidung trifft nginx bei jeder Anfrage neu.
 *
 * ## Warum diese Form und keine kürzere
 *
 * Jede Zeile ist gemessen (`docs/81 §2.3p`), und die naheliegenden Fassungen
 * sind beide falsch:
 *
 * **M24 — ein `if` auf Serverebene ohne Ausnahme nimmt die Prüfadresse mit.**
 * Es läuft in der Rewrite-Phase, also **vor** der Auswahl der `location`; die
 * eigene `location ^~` von {@see HttpChallenge} kommt gar nicht zum Zug.
 * Während einer Wartung stürbe jede Zertifikatserneuerung, lautlos.
 *
 * **M25 — ein `if` in `location /` deckt PHP nicht ab.** `location ~ \.php$`
 * steht **innerhalb** von `location /`, und ein `if` der äusseren gilt für die
 * innere nicht: statische Dateien 503, PHP weiter bedient.
 *
 * **M26 — und `nginx -t` unterscheidet die beiden nicht**, beide geben `rc=0`.
 * Der Sollzustand gehört deshalb in die Zusage der Vorlage
 * ({@see SiteTemplate::PROMISED_BY_FORM}) und nicht in den Prüfer.
 *
 * > **Ein Prüfer, der beide Fassungen für gültig hält, sagt über die Wirkung
 * > nichts — und die kaputte ist die, die man zuerst schreibt.**
 *
 * **M27 — `add_header` ist in einem `if` auf Serverebene nicht erlaubt**
 * (`nginx -t` gibt `rc=1`). Deshalb die benannte Fehler-`location`: Sie trägt
 * Rumpf und Header, und `error_page` schickt die Anfrage dorthin.
 *
 * ## Was der Ablageort mit `docs/78` zu tun hat
 *
 * `/var/spool` und nicht `/var/lib/srvpanel` — aus demselben Grund wie die
 * ACME-Prüfdatei: Das Verzeichnis des Panels ist `0750 srvpanel:srvpanel`, und
 * der nginx-Worker läuft als `www-data`. Eine Datei, die für alle lesbar ist,
 * ist damit nicht erreichbar; der Weg zu ihr entscheidet.
 */
final class Maintenance
{
    /**
     * Die Datei, deren Anwesenheit den Wartungsmodus einschaltet.
     *
     * Nicht unter `/run`: Ein Neustart des Servers löschte sie dort, und der
     * Modus wäre danach still aus — ohne dass jemand ihn ausgeschaltet hätte.
     */
    public const FLAG = '/var/spool/srvpanel/wartung';

    /**
     * Die Form, in der eine voraussichtliche Endzeit ankommen darf.
     *
     * **Die Prüfung ist die Grenze und nicht eine Höflichkeit.** Die Angabe
     * landet als Text *in* einer nginx-Zeichenkette; ein Apostroph darin
     * beendete sie, und aus einer Auskunft würde eine Konfigurationszeile. Was
     * hier durchkommt, kann nur aus Ziffern, Bindestrichen, einem Doppelpunkt
     * und einem Leerzeichen bestehen.
     *
     * `Y-m-d H:i` ist dabei kein neues Format, sondern das der Anzeige — es
     * steht so auch an jedem Zertifikat („gültig bis …").
     */
    public const UNTIL = '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/D';

    /**
     * Die Form, in der die Zone dieser Endzeit ankommen darf.
     *
     * **Gemessen und nicht abgelesen.** Über alle Zeitzonen von PHP, in beiden
     * Hälften des Jahres, hat die Abkürzung drei Formen: Buchstaben (`GMT`,
     * `CEST`, `EEST`, höchstens fünf), einen kurzen Versatz (`+03`, `-11`) und
     * einen langen (`+0530`). Wer sie an der eigenen Zone abliest, kennt eine
     * von dreien und weist die anderen beiden ab.
     *
     * Dazu die Sonderform `UTC` ohne Klammer: Die Beschriftung des Panels
     * (`App\Support\Time\Clock::label()`, hier bewusst ohne `@see` — der
     * Agent bindet nichts aus der Anwendung ein, und Pint machte aus einer
     * Marke einen `use`-Eintrag) lässt den Zusatz dort weg, weil
     * `UTC (UTC+00:00)` sich selbst erklärt.
     *
     * Dieselbe Grenze wie bei {@see self::UNTIL}: Der Wert landet als Text *in*
     * einer nginx-Zeichenkette.
     */
    public const ZONE = '/^(?:UTC|(?:[A-Za-z]{1,5}|[+-]\d{2}(?:\d{2})?) \(UTC[+-]\d{2}:\d{2}\))$/D';

    /**
     * Die geprüfte Endzeit — oder `null`, wenn keine mitkam.
     *
     * Eine Angabe, die die Form nicht hält, ist ein Programmierfehler des
     * Panels und keine Eingabe eines Kunden: Sie wird abgewiesen und nicht
     * stillschweigend weggelassen.
     */
    public static function until(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (! is_string($value) || preg_match(self::UNTIL, $value) !== 1) {
            throw AgentException::badRequest(
                'Die voraussichtliche Endzeit muss die Form JJJJ-MM-TT HH:MM haben.',
                ['maintenance_until' => is_scalar($value) ? (string) $value : gettype($value)],
            );
        }

        return $value;
    }

    /**
     * Die geprüfte Zone dieser Endzeit — oder `null`, wenn keine mitkam.
     *
     * **Fehlt sie, entfällt der Zusatz und nichts weiter.** Eine Endzeit ohne
     * Zone ist der Zustand vor dem 4. September 2026 und bleibt lesbar; eine
     * Zone, die die Form nicht hält, ist ein Programmierfehler des Panels und
     * wird abgewiesen — dieselbe Richtung wie bei {@see self::until()}.
     */
    public static function zone(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (! is_string($value) || preg_match(self::ZONE, $value) !== 1) {
            throw AgentException::badRequest(
                'Die Zeitzone der Endzeit muss die Form „CEST (UTC+02:00)" haben.',
                ['maintenance_zone' => is_scalar($value) ? (string) $value : gettype($value)],
            );
        }

        return $value;
    }

    /**
     * Die Wache für einen Server-Block, samt ihrer benannten Fehler-location.
     *
     * **Die Ausnahme kommt aus {@see HttpChallenge::PREFIX} und
     * {@see HttpChallenge::TOKEN} und wird nicht danebengeschrieben.** Zwei
     * Listen, die dasselbe meinen, laufen auseinander — und die zweite ist die,
     * die veraltet. `preg_quote` macht daraus einen Ausdruck; nginx spricht
     * PCRE, die Ausgabe passt also.
     *
     * ## `$request_uri` und nicht `$uri` — gemessen am 4. September 2026
     *
     * Der erste Wurf fragte `$uri`, und auf `cloudsrv24` gab die Prüfadresse
     * während einer Wartung **503** statt 404 — aber nur im HTTPS-Block, nicht
     * im Block auf Port 80.
     *
     * Der Grund ist `try_files $uri $uri/ /index.php` einer PHP-Domain: Das ist
     * eine **innere Umleitung**, und nginx durchläuft die Rewrite-Phase des
     * Servers dabei **noch einmal** — mit `$uri` = `/index.php`. Beim zweiten
     * Durchgang passt die Ausnahme nicht mehr, `$wartung` wird wieder 1, und
     * die Wache greift.
     *
     * > **Ein `if` auf Serverebene läuft bei jeder inneren Umleitung noch
     * > einmal — und die Ausnahme, die beim ersten Mal griff, greift beim
     * > zweiten nicht mehr.**
     *
     * Auf Port 80 fiel es nicht auf, weil dort die eigene `location ^~` von
     * {@see HttpChallenge} die Anfrage abfängt, bevor `try_files` sie umleiten
     * kann — zwei Blöcke mit derselben Wache, verschieden im Ausgang.
     *
     * `$request_uri` ist die **ursprüngliche** Adresse und ändert sich bei einer
     * inneren Umleitung nicht. Weil sie dafür unnormalisiert ist, endet der
     * Ausdruck am Token: `..` und ein Unterpfad kommen darin nicht vor, und
     * niemand kann sich über einen ACME-Pfad an der Wartungsseite vorbeischreiben.
     *
     * Eine Abfrage dahinter ist zugelassen, obwohl RFC 8555 §8.3 keine kennt:
     * Sie kann keinen Pfad öffnen — `$uri` ist da längst abgetrennt —, und der
     * Fehler soll zur sicheren Seite fallen. **Eine verpasste Ausnahme kostet
     * ein Zertifikat, eine zu weite einen Blick auf die Website.**
     *
     * **Und er trägt keine Längengrenze, sondern nur ein `+`.** Nicht aus
     * Bequemlichkeit: `{16,128}` müsste in Anführungszeichen stehen, damit
     * nginx die Klammern nicht als Blockgrenzen liest — und
     * {@see Statements::nginx()} zerlegt eine Datei
     * an `;{}`, **ohne Anführungszeichen zu kennen**. Der Nachtlauf von A10
     * meldete daraufhin erfundene Anweisungen für jede heile Domain.
     *
     * > **Ein Ausdruck, der in eine Datei geht, die ein anderer Leser zerlegt,
     * > meidet dessen Trennzeichen — oder der Leser muss sie verstehen.**
     *
     * Die Länge fehlt hier nichts: Sicherheit trägt die **Zeichenklasse**
     * (kein `/`, kein `.`, kein `?`), und ein zu kurzer Token wird von
     * {@see HttpChallenge} abgewiesen, sobald er eine Datei sucht.
     */
    public static function nginxGuard(?string $until, ?string $zone): string
    {
        [$setzen, $flagge, $ausnahme, $urteil, $seite, $ort] = self::guardLines();
        $page = self::page($until, $zone);

        return <<<CONF
            # **Wartungsmodus.** Liegt die Datei, antwortet diese Domain mit 503
            # — bis auf die Prüfadresse von ACME, sonst stürbe während jeder
            # Wartung die Zertifikatserneuerung (docs/81 §2.3p, M24).
            #
            # Auf Serverebene und nicht in `location /`: Dort deckte es die
            # verschachtelte PHP-location nicht ab (M25).
            {$setzen}
            {$flagge}
            {$ausnahme}
            {$urteil}

            # `add_header` ist in einem `if` auf Serverebene nicht erlaubt (M27)
            # — Rumpf und Header stehen deshalb hier.
            {$seite}
            {$ort}
                add_header Retry-After 3600 always;
                default_type text/html;
                return 503 '{$page}';
            }
        CONF;
    }

    /**
     * Die Zeilen der Wache, die von Zeit und Zone **unabhängig** sind.
     *
     * ## Warum es sie gibt
     *
     * Die Bestandsdiagnose vergleicht damit, was in einer Vhost-Datei
     * tatsächlich steht (`docs/101 §5`, Grund `guard_missing`). Sie **darf
     * dafür nicht die Seite mitnehmen**: Ändert der Betreiber die Endzeit,
     * tragen die Blöcke sie erst nach dem Rundlauf der Warteschlange, und eine
     * Prüfung über die ganze Wache meldete solange jede heile Domain.
     *
     * > **Ein Sollzustand, der sich häufiger ändert als der Prüfling, meldet
     * > den Abstand und nicht den Schaden.**
     *
     * ## Warum sie hier steht und nicht in der Prüfung
     *
     * Der Sollzustand kommt aus der Vorlage und wird nicht nachgebaut — dieselbe
     * Regel, an der `PROMISED_BY_FORM` in {@see SiteTemplate} hängt. Eine
     * zweite Fassung dieser sechs Zeilen liefe auseinander, und die
     * auseinandergelaufene entschiede dann jede Nacht über jede Domain.
     *
     * **Warum die `location`-Zeile mitzählt:** Ohne sie beantwortet
     * `error_page 503 @wartung` ins Leere, und nginx liefert seine eigene
     * 503-Seite aus — ohne `Retry-After` und ohne die Zeitangabe. Das ist ein
     * Schaden, den weder `nginx -t` noch die Zusage je Anweisungsname sieht.
     *
     * @return array{0: string, 1: string, 2: string, 3: string, 4: string, 5: string}
     */
    public static function guardLines(): array
    {
        $flag = self::FLAG;
        $prefix = preg_quote(HttpChallenge::PREFIX);
        $token = HttpChallenge::TOKEN_CHARS.'+';

        return [
            'set $wartung 0;',
            sprintf('if (-f %s) { set $wartung 1; }', $flag),
            sprintf('if ($request_uri ~ ^%s/%s(\?.*)?$) { set $wartung 0; }', $prefix, $token),
            'if ($wartung = 1) { return 503; }',
            'error_page 503 @wartung;',
            'location @wartung {',
        ];
    }

    /**
     * Die Seite, die ein Besucher während der Wartung liest.
     *
     * **Feste Form und kein Freitext** (`docs/101 §2`): Der informative Teil
     * ist die Zeitangabe, und die ist ein typisierter Wert. Kein „wenden Sie
     * sich an den Betreiber" — das ist die Sperrseite, und die verlangt vom
     * Leser etwas. Bei einer Wartung gibt es für ihn nichts zu tun.
     */
    private static function page(?string $until, ?string $zone): string
    {
        // „2026-09-04 16:00 Uhr CEST (UTC+02:00)" — ohne Zone endet es nach „Uhr".
        $zeitpunkt = $until === null ? null : rtrim($until.' Uhr '.($zone ?? ''));

        $satz = $zeitpunkt === null
            ? 'Diese Website ist wegen Wartungsarbeiten vorübergehend nicht erreichbar.'
            : sprintf(
                'Diese Website ist wegen Wartungsarbeiten vorübergehend nicht erreichbar. '.
                'Voraussichtlich ab %s wieder erreichbar.',
                $zeitpunkt,
            );

        return '<!doctype html><html lang=de><head><meta charset=utf-8>'.
               '<meta name=viewport content=width=device-width,initial-scale=1>'.
               '<title>Wartungsarbeiten</title></head><body>'.
               '<h1>Wartungsarbeiten</h1>'.
               '<p>'.$satz.'</p>'.
               '</body></html>';
    }
}
